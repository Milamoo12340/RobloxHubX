# BIG Games Affiliated Developers Research
## Researching BIG Games and all affiliated groups
## Researching BIG Games Developer IDs using browser
## Confirmed BIG Games Developers
## Confirmed BIG Games Groups
## Current vs. Verified Developer List Comparison
## Current vs. Verified Group List Comparison
## Search Criteria for New Assets
