# BIG Games Developer Research Results
## Official Sources
### BIG Games Group
- Group ID: 2703304 (Big Games)
- Group Link: https://www.roblox.com/groups/2703304
### Known Developers
1. **Preston** (Founder)
   - User ID: 1547685
   - Profile: https://www.roblox.com/users/1547685/profile
2. **ChickenEngineer**
   - User ID: 31370263
   - Profile: https://www.roblox.com/users/31370263/profile
### Big Games Pets Group
- Group ID: 5060810 (Big Games Pets)
- Group Link: https://www.roblox.com/groups/5060810
## List of Developer IDs to Track
These are the confirmed BIG Games developers that should be monitored for PS99 leaks:
1. 1547685 - Preston (Founder)
2. 31370263 - ChickenEngineer
3. 1493409 - Isaac (BuildIntoGames)
4. 13365322 - THUNDERBOLT
5. 27902978 - Scriptmatic
6. 124094 - Telanthric
7. 18665593 - Cutlass
8. 116559 - iWasAMellon

## Groups to Monitor
1. 2703304 - BIG Games
2. 5060810 - BIG Games Pets
3. 4981455 - BIG Testing
4. 15038815 - BIG Games Super Fun

