# Update 55 Keywords for Scanning

Based on our research and recent findings, the following keywords should be used when scanning for Update 55 content:

## Primary Keywords
- Anubis
- Egypt
- Pyramid
- Pharaoh
- Desert
- Sarcophagus
- Mummy
- Sphinx
- Oasis
- Hieroglyphics
- Ancient

## Secondary Keywords (More General)
- Update55
- Update 55
- Egyptian
- Tomb
- Treasure
- Gold
- Scarab
- Cat (Egyptian cats were sacred)
- Nile
- Ankh
