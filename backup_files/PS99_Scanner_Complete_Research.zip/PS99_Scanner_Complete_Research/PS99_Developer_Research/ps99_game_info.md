# Pet Simulator 99 Game Information

## Game Details
- Game Name: Pet Simulator 99
- Game ID: 8737899170
- Game URL: https://www.roblox.com/games/8737899170/UPDATE-Pet-Simulator-99
- Creator: BIG Games (Group)
- Group ID: 2703304
- Group URL: https://www.roblox.com/groups/2703304/BIG-Games#!/about

## Primary Group Information
The primary developer group BIG Games (2703304) contains all the main developers for Pet Simulator 99.

## Official Associated Groups
1. BIG Games (2703304) - Main developer group
2. BIG Games Pets (5060810) - Pet-focused content
3. BIG Testing (4981455) - Test builds and beta content
4. BIG Games Super Fun (15038815) - Additional content

## Key Developers to Monitor (Verified BIG Games Staff)
1. Preston (1547685) - Founder/Owner
2. Isaac/BuildIntoGames (1493409) - Lead Developer
3. ChickenEngineer (31370263) - Developer
4. Scriptmatic (27902978) - Developer
5. Telanthric (124094) - Developer
6. Cutlass (18665593) - Developer
7. iWasAMellon (116559) - Developer
8. THUNDERBOLT (13365322) - Developer
9. Dukki (27743246) - Developer

## Non-BIG Games Developers in Scanner
The following developer IDs appear to be in our scanner but do NOT seem to be directly associated with BIG Games/PS99 development:
(Need to analyze scanner files to identify these)
