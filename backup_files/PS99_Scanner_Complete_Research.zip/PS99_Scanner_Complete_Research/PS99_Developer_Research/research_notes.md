# PS99 Developer Research
## Roblox BIG Games Developer Information
Researching official BIG Games developer profiles...
## Searching for BIG Games official Roblox group and ID
Using the search results to find the official BIG Games group ID and profile page...
## Researching Preston (Founder of BIG Games)
Preston+Roblox
## Searching specifically for BIG Games Roblox Group ID and Known Developer IDs
## Known Developers Research
### Researching ChickenEngineer and other known developers
## Examining scanner files for developer IDs
../PS99_Leak_Detector_Ultra/static/images/assets/Pasted--Implemented-comprehensive-Roblox-asset-scanner-for-PS99-Added-retry-logic-with-exponential-backo-1744361605945.txt:DEVELOPER_IDS = [
../PS99_Leak_Detector_Ultra/static/images/assets/Pasted--Implemented-comprehensive-Roblox-asset-scanner-for-PS99-Added-retry-logic-with-exponential-backo-1744362226798.txt:DEVELOPER_IDS = [
../PS99_Leak_Detector_Ultra/app.py:DEVELOPER_IDS = [
../PS99_Leak_Detector_Ultra/app.py:        developer_ids=DEVELOPER_IDS,
../PS99_Leak_Detector_Ultra/view_leaks.py:DEVELOPER_IDS = [
../PS99_Leak_Detector_Ultra/view_leaks.py:    for dev_id in DEVELOPER_IDS:
../PS99_Leak_Detector_Ultra/display_assets.py:DEVELOPER_IDS = [
../PS99_Leak_Detector_Ultra/display_assets.py:    for dev_id in DEVELOPER_IDS:
## Checking for existing group IDs in scanner
../PS99_Leak_Detector_Ultra/app.py:GROUP_IDS = [
../PS99_Leak_Detector_Ultra/app.py:        group_ids=GROUP_IDS,
## Recent scanner findings
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py:                                logger.info(f"★★★ POTENTIAL ANUBIS UPDATE ASSET FOUND: {asset_data['name']} ★★★")
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py-                except Exception as e:
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py-                    logger.error(f"Error processing collection item for user {user_id}: {e}")
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py-                    
--
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py:                                logger.info(f"★★★ POTENTIAL ANUBIS UPDATE ASSET FOUND: {asset_data['name']} ★★★")
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py-                except Exception as e:
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py-                    logger.error(f"Error processing catalog item for user {user_id}: {e}")
../PS99_Leak_Detector_Ultra/collection_roblox_scanner.py-                    
--
## Searching for Pet Simulator 99 game page
Extracting PS99 game link and developer info...
