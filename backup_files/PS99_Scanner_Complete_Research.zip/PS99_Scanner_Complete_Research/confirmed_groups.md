# Confirmed BIG Games Groups

1. **BIG Games** - Main developer group
   - Group ID: 2703304
   - Link: https://www.roblox.com/groups/2703304/BIG-Games

2. **BIG Games Pets** - Pet-focused content team
   - Group ID: 5060810
   - Link: https://www.roblox.com/groups/5060810/BIG-Games-Pets

3. **BIG Testing** - Test builds and beta content
   - Group ID: 4981455
   - Link: https://www.roblox.com/groups/4981455/BIG-Testing

4. **BIG Games Super Fun** - Additional content team
   - Group ID: 15038815
   - Link: https://www.roblox.com/groups/15038815/BIG-Games-Super-Fun

5. **BIG Games Magic Forest** - Themed group for specific games
   - Group ID: 14078260
   - Link: https://www.roblox.com/groups/14078260/BIG-Games-Magic-Forest

6. **BIG Games Fishing** - Themed development group
   - Group ID: 16284024
   - Link: https://www.roblox.com/groups/16284024/BIG-Games-Fishing
