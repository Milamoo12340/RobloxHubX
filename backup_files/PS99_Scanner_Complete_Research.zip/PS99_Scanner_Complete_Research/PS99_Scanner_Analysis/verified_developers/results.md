# Verified PS99 Developer Analysis
## Confirmed BIG Games Developers
The following developers are confirmed to be associated with BIG Games/Pet Simulator 99:

1. 1547685 - Preston (Founder of BIG Games)
2. 1493409 - Isaac/BuildIntoGames (Lead Developer)
3. 31370263 - ChickenEngineer (Developer)
4. 13365322 - THUNDERBOLT (Developer)
5. 27902978 - Scriptmatic (Developer)
6. 27743246 - Dukki (Developer) 
7. 124094 - Telanthric (Developer)
8. 18665593 - Cutlass (Developer)
9. 116559 - iWasAMellon (Developer)

## Confirmed BIG Games Groups
The following groups are confirmed to be associated with BIG Games/Pet Simulator 99:

1. 2703304 - BIG Games (Main developer group)
2. 5060810 - BIG Games Pets (Pet-focused content)
3. 4981455 - BIG Testing (Test builds and beta content)
4. 15038815 - BIG Games Super Fun (Additional content)

## Developers in Current Scanner Not Confirmed as BIG Games Developers
The following developer IDs in our current scanner need to be verified:

1. 97658457 - Need to verify
2. 154740428 - Need to verify
3. 83364191 - Need to verify
4. 98346734 - Need to verify
5. 79187030 - Need to verify
6. 6523651 - Need to verify
7. 28100481 - Need to verify
8. 19339635 - Need to verify
9. 47296135 - Need to verify
10. 17122595 - Need to verify
11. 116705184 - Need to verify
12. 94730921 - Need to verify
13. 23558830 - Need to verify
14. 16015415 - Need to verify
## Groups in Current Scanner Not Confirmed as BIG Games Groups
The following group IDs in our current scanner need to be verified:

1. 3959677 - Need to verify
2. 35517943 - Need to verify
3. 10026748 - Need to verify
4. 9950771 - Need to verify
5. 4625640 - Need to verify
6. 8287292 - Need to verify
7. 7209850 - Need to verify
8. 14078260 - Need to verify
9. 16284024 - Need to verify
10. 14398517 - Need to verify
11. 11396125 - Need to verify
12. 10425923 - Need to verify
