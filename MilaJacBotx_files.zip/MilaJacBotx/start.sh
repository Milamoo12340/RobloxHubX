#!/bin/bash
echo "Starting PS99 Asset Tracker System..."
echo ""
echo "This will run the complete tracking system."
echo "Discoveries will be sent to your Discord webhooks."
echo ""
echo "Press Ctrl+C to stop the tracker."
echo ""
node run-all-ps99-trackers.cjs