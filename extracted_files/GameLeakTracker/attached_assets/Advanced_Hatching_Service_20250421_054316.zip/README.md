# Advanced Hatching Service

This package contains the web-based Advanced Hatching Service:

## Core Components
- Standalone service that works with or without admin privileges
- Web interface for remote access from any device
- Multiple implementation methods based on available permissions
- Five different hatching modes with customizable settings

## Installation
1. Install required dependencies:
   ```pip install flask flask-login flask-sqlalchemy```
2. Run the application:
   ```python main.py```
3. Access the web interface at http://localhost:5000

## Default Login
- Username: admin
- Password: admin (change immediately after first login)
