"""
Advanced Hatching Service - Web Interface

This module provides a web interface to control the advanced egg hatching
manipulation feature from a deployed web app.
"""

import os
import sys
import time
import json
import logging
import threading
from datetime import datetime
from typing import Dict, Any, Optional, List, Union

from flask import Flask, request, jsonify, render_template, redirect, url_for, session
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
import gevent
from gevent import monkey
from gevent.pywsgi import WSGIServer

# Patch standard library for gevent
monkey.patch_all()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("web_server.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("WebInterface")

# Import the hatching service
from advanced_hatching_service import (
    HatchingService, HatchConfig, HatchRateMode, 
    SecurityLevel, ImplementationMethod, OperationMode
)

class Base(DeclarativeBase):
    pass

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "advanced_hatching_service_secret")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize database
db = SQLAlchemy(app, model_class=Base)

# Initialize login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# Create the hatching service
hatching_service = HatchingService()

# Active client connections
active_clients = {}

# Database models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class HatchingSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    start_time = db.Column(db.DateTime, default=datetime.utcnow)
    end_time = db.Column(db.DateTime)
    mode = db.Column(db.Integer, nullable=False)
    implementation_method = db.Column(db.String(50), nullable=False)
    total_hatches = db.Column(db.Integer, default=0)
    rare_plus_hatches = db.Column(db.Integer, default=0)
    legendary_plus_hatches = db.Column(db.Integer, default=0)
    
    user = db.relationship('User', backref=db.backref('sessions', lazy=True))

class HatchingConfiguration(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(64), nullable=False)
    mode = db.Column(db.Integer, nullable=False)
    common_rate = db.Column(db.Float, default=0.70)
    rare_rate = db.Column(db.Float, default=0.20)
    epic_rate = db.Column(db.Float, default=0.06)
    legendary_rate = db.Column(db.Float, default=0.03)
    mythical_rate = db.Column(db.Float, default=0.007)
    secret_rate = db.Column(db.Float, default=0.003)
    enable_golden = db.Column(db.Boolean, default=False)
    enable_rainbow = db.Column(db.Boolean, default=False)
    enable_shiny = db.Column(db.Boolean, default=False)
    implementation_method = db.Column(db.String(50), default="network_intercept")
    security_level = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    user = db.relationship('User', backref=db.backref('configurations', lazy=True))

# Create database tables
with app.app_context():
    db.create_all()
    
    # Create admin user if it doesn't exist
    admin = User.query.filter_by(username="admin").first()
    if not admin:
        admin = User(username="admin", is_admin=True)
        admin.set_password("admin")  # Default password should be changed immediately
        db.session.add(admin)
        db.session.commit()
        logger.info("Created admin user")

# User loader for login manager
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Routes
@app.route('/')
def index():
    """Homepage"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        if user and user.check_password(password):
            login_user(user)
            user.last_login = datetime.utcnow()
            db.session.commit()
            return redirect(url_for('dashboard'))
        
        return render_template('login.html', error="Invalid username or password")
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    """Logout"""
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Main dashboard"""
    status = hatching_service.get_status()
    
    # Get user's configurations
    configs = HatchingConfiguration.query.filter_by(user_id=current_user.id).all()
    
    # Get recent sessions
    sessions = HatchingSession.query.filter_by(user_id=current_user.id).order_by(HatchingSession.start_time.desc()).limit(5).all()
    
    return render_template('dashboard.html', 
                          status=status, 
                          configs=configs, 
                          sessions=sessions)

@app.route('/service/start', methods=['POST'])
@login_required
def start_service():
    """Start the hatching service"""
    config_id = request.form.get('config_id')
    
    if config_id:
        # Load configuration from database
        config = HatchingConfiguration.query.get(config_id)
        if config and config.user_id == current_user.id:
            # Update service configuration
            new_config = {
                "mode": config.mode,
                "common_rate": config.common_rate,
                "rare_rate": config.rare_rate,
                "epic_rate": config.epic_rate,
                "legendary_rate": config.legendary_rate,
                "mythical_rate": config.mythical_rate,
                "secret_rate": config.secret_rate,
                "enable_golden": config.enable_golden,
                "enable_rainbow": config.enable_rainbow,
                "enable_shiny": config.enable_shiny,
                "implementation_method": config.implementation_method,
                "security_level": config.security_level
            }
            hatching_service.set_configuration(new_config)
    
    # Start the service
    if hatching_service.start():
        # Create a new session record
        session = HatchingSession(
            user_id=current_user.id,
            mode=hatching_service.config.mode,
            implementation_method=hatching_service.config.implementation_method
        )
        db.session.add(session)
        db.session.commit()
        
        return jsonify({"success": True, "message": "Service started successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to start service"})

@app.route('/service/stop', methods=['POST'])
@login_required
def stop_service():
    """Stop the hatching service"""
    if hatching_service.stop():
        # Update any active session
        session = HatchingSession.query.filter_by(
            user_id=current_user.id, 
            end_time=None
        ).order_by(HatchingSession.start_time.desc()).first()
        
        if session:
            session.end_time = datetime.utcnow()
            stats = hatching_service.get_status()["stats"]
            session.total_hatches = stats["total_hatches"]
            session.rare_plus_hatches = stats["rare_hatches"] + stats["epic_hatches"] + stats["legendary_hatches"] + stats["mythical_hatches"] + stats["secret_hatches"]
            session.legendary_plus_hatches = stats["legendary_hatches"] + stats["mythical_hatches"] + stats["secret_hatches"]
            db.session.commit()
        
        return jsonify({"success": True, "message": "Service stopped successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to stop service"})

@app.route('/service/status')
@login_required
def get_status():
    """Get the current service status"""
    status = hatching_service.get_status()
    return jsonify(status)

@app.route('/service/config', methods=['GET'])
@login_required
def get_config():
    """Get the current service configuration"""
    config = hatching_service.config.to_dict()
    return jsonify(config)

@app.route('/service/config', methods=['POST'])
@login_required
def update_config():
    """Update the service configuration"""
    config_data = request.json
    if hatching_service.set_configuration(config_data):
        return jsonify({"success": True, "message": "Configuration updated successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to update configuration"})

@app.route('/service/mode', methods=['POST'])
@login_required
def set_mode():
    """Set the hatching mode"""
    mode = request.json.get('mode')
    if mode is None:
        return jsonify({"success": False, "message": "Mode is required"})
    
    if hatching_service.set_mode(mode):
        return jsonify({"success": True, "message": f"Mode set to {mode}"})
    else:
        return jsonify({"success": False, "message": "Failed to set mode"})

@app.route('/service/stats/reset', methods=['POST'])
@login_required
def reset_stats():
    """Reset the hatching statistics"""
    hatching_service.reset_stats()
    return jsonify({"success": True, "message": "Statistics reset successfully"})

@app.route('/config/save', methods=['POST'])
@login_required
def save_config():
    """Save the current configuration"""
    name = request.form.get('name')
    if not name:
        return jsonify({"success": False, "message": "Configuration name is required"})
    
    # Get current config
    config = hatching_service.config
    
    # Save to database
    saved_config = HatchingConfiguration(
        user_id=current_user.id,
        name=name,
        mode=config.mode,
        common_rate=config.common_rate,
        rare_rate=config.rare_rate,
        epic_rate=config.epic_rate,
        legendary_rate=config.legendary_rate,
        mythical_rate=config.mythical_rate,
        secret_rate=config.secret_rate,
        enable_golden=config.enable_golden,
        enable_rainbow=config.enable_rainbow,
        enable_shiny=config.enable_shiny,
        implementation_method=config.implementation_method,
        security_level=config.security_level
    )
    
    db.session.add(saved_config)
    db.session.commit()
    
    return jsonify({
        "success": True, 
        "message": "Configuration saved successfully",
        "config_id": saved_config.id
    })

@app.route('/config/delete/<int:config_id>', methods=['POST'])
@login_required
def delete_config(config_id):
    """Delete a saved configuration"""
    config = HatchingConfiguration.query.get(config_id)
    if config and config.user_id == current_user.id:
        db.session.delete(config)
        db.session.commit()
        return jsonify({"success": True, "message": "Configuration deleted successfully"})
    
    return jsonify({"success": False, "message": "Configuration not found"})

@app.route('/config/load/<int:config_id>', methods=['POST'])
@login_required
def load_config(config_id):
    """Load a saved configuration"""
    config = HatchingConfiguration.query.get(config_id)
    if config and config.user_id == current_user.id:
        # Update service configuration
        new_config = {
            "mode": config.mode,
            "common_rate": config.common_rate,
            "rare_rate": config.rare_rate,
            "epic_rate": config.epic_rate,
            "legendary_rate": config.legendary_rate,
            "mythical_rate": config.mythical_rate,
            "secret_rate": config.secret_rate,
            "enable_golden": config.enable_golden,
            "enable_rainbow": config.enable_rainbow,
            "enable_shiny": config.enable_shiny,
            "implementation_method": config.implementation_method,
            "security_level": config.security_level
        }
        if hatching_service.set_configuration(new_config):
            return jsonify({"success": True, "message": "Configuration loaded successfully"})
        else:
            return jsonify({"success": False, "message": "Failed to load configuration"})
    
    return jsonify({"success": False, "message": "Configuration not found"})

@app.route('/admin')
@login_required
def admin_dashboard():
    """Admin dashboard"""
    if not current_user.is_admin:
        return redirect(url_for('dashboard'))
    
    # Get all users
    users = User.query.all()
    
    # Get all sessions
    sessions = HatchingSession.query.order_by(HatchingSession.start_time.desc()).limit(20).all()
    
    # Get hatching service status
    status = hatching_service.get_status()
    
    return render_template('admin.html', 
                          users=users, 
                          sessions=sessions, 
                          status=status)

@app.route('/admin/user/create', methods=['POST'])
@login_required
def create_user():
    """Create a new user"""
    if not current_user.is_admin:
        return jsonify({"success": False, "message": "Admin privileges required"})
    
    username = request.form.get('username')
    password = request.form.get('password')
    is_admin = request.form.get('is_admin') == 'on'
    
    if not username or not password:
        return jsonify({"success": False, "message": "Username and password are required"})
    
    # Check if user already exists
    if User.query.filter_by(username=username).first():
        return jsonify({"success": False, "message": "Username already exists"})
    
    # Create new user
    user = User(username=username, is_admin=is_admin)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()
    
    return jsonify({"success": True, "message": "User created successfully"})

@app.route('/admin/user/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    """Delete a user"""
    if not current_user.is_admin:
        return jsonify({"success": False, "message": "Admin privileges required"})
    
    # Cannot delete self
    if user_id == current_user.id:
        return jsonify({"success": False, "message": "Cannot delete yourself"})
    
    user = User.query.get(user_id)
    if user:
        db.session.delete(user)
        db.session.commit()
        return jsonify({"success": True, "message": "User deleted successfully"})
    
    return jsonify({"success": False, "message": "User not found"})

@app.route('/admin/service/reset', methods=['POST'])
@login_required
def reset_service():
    """Reset the hatching service (admin only)"""
    if not current_user.is_admin:
        return jsonify({"success": False, "message": "Admin privileges required"})
    
    hatching_service.stop()
    hatching_service.reset_stats()
    
    # Reset to default configuration
    default_config = HatchConfig()
    hatching_service.set_configuration(default_config.to_dict())
    
    return jsonify({"success": True, "message": "Service reset successfully"})

@app.route('/admin/stats')
@login_required
def admin_stats():
    """Admin statistics page"""
    if not current_user.is_admin:
        return redirect(url_for('dashboard'))
    
    # Get user counts
    user_count = User.query.count()
    active_user_count = db.session.query(db.func.count(db.distinct(HatchingSession.user_id))).filter(
        HatchingSession.start_time >= datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    ).scalar()
    
    # Get total hatches
    total_hatches = db.session.query(db.func.sum(HatchingSession.total_hatches)).scalar() or 0
    
    # Get hatches by mode
    hatches_by_mode = db.session.query(
        HatchingSession.mode,
        db.func.sum(HatchingSession.total_hatches)
    ).group_by(HatchingSession.mode).all()
    
    # Get hatches by implementation method
    hatches_by_method = db.session.query(
        HatchingSession.implementation_method,
        db.func.sum(HatchingSession.total_hatches)
    ).group_by(HatchingSession.implementation_method).all()
    
    return render_template('admin_stats.html',
                          user_count=user_count,
                          active_user_count=active_user_count,
                          total_hatches=total_hatches,
                          hatches_by_mode=hatches_by_mode,
                          hatches_by_method=hatches_by_method)

# API routes for remote access
@app.route('/api/ping', methods=['GET'])
def api_ping():
    """Simple ping endpoint"""
    return jsonify({"status": "ok", "time": datetime.now().isoformat()})

@app.route('/api/status', methods=['GET'])
def api_status():
    """Get the current status of the hatching service"""
    # This endpoint is public for basic status checks
    status = hatching_service.get_status()
    return jsonify(status)

@app.route('/api/auth', methods=['POST'])
def api_auth():
    """Authenticate API client"""
    username = request.json.get('username')
    password = request.json.get('password')
    
    if not username or not password:
        return jsonify({"success": False, "message": "Username and password are required"}), 400
    
    user = User.query.filter_by(username=username).first()
    if user and user.check_password(password):
        # Generate a token
        token = os.urandom(24).hex()
        
        # Store in active clients
        active_clients[token] = {
            "user_id": user.id,
            "username": user.username,
            "created_at": datetime.utcnow(),
            "last_access": datetime.utcnow()
        }
        
        return jsonify({"success": True, "token": token})
    
    return jsonify({"success": False, "message": "Invalid credentials"}), 401

def require_api_auth(f):
    """Decorator to require API authentication"""
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header.split(' ')[1]
            if token in active_clients:
                # Update last access time
                active_clients[token]["last_access"] = datetime.utcnow()
                # Set current user ID
                kwargs['user_id'] = active_clients[token]["user_id"]
                return f(*args, **kwargs)
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    decorated.__name__ = f.__name__
    return decorated

@app.route('/api/service/start', methods=['POST'])
@require_api_auth
def api_start_service(user_id):
    """Start the hatching service via API"""
    config_data = request.json.get('config')
    if config_data:
        if not hatching_service.set_configuration(config_data):
            return jsonify({"success": False, "message": "Invalid configuration"}), 400
    
    if hatching_service.start():
        # Create a new session record
        session = HatchingSession(
            user_id=user_id,
            mode=hatching_service.config.mode,
            implementation_method=hatching_service.config.implementation_method
        )
        db.session.add(session)
        db.session.commit()
        
        return jsonify({"success": True, "message": "Service started successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to start service"}), 500

@app.route('/api/service/stop', methods=['POST'])
@require_api_auth
def api_stop_service(user_id):
    """Stop the hatching service via API"""
    if hatching_service.stop():
        # Update any active session
        session = HatchingSession.query.filter_by(
            user_id=user_id, 
            end_time=None
        ).order_by(HatchingSession.start_time.desc()).first()
        
        if session:
            session.end_time = datetime.utcnow()
            stats = hatching_service.get_status()["stats"]
            session.total_hatches = stats["total_hatches"]
            session.rare_plus_hatches = stats["rare_hatches"] + stats["epic_hatches"] + stats["legendary_hatches"] + stats["mythical_hatches"] + stats["secret_hatches"]
            session.legendary_plus_hatches = stats["legendary_hatches"] + stats["mythical_hatches"] + stats["secret_hatches"]
            db.session.commit()
        
        return jsonify({"success": True, "message": "Service stopped successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to stop service"}), 500

@app.route('/api/service/config', methods=['GET'])
@require_api_auth
def api_get_config(user_id):
    """Get the current service configuration via API"""
    config = hatching_service.config.to_dict()
    return jsonify(config)

@app.route('/api/service/config', methods=['POST'])
@require_api_auth
def api_update_config(user_id):
    """Update the service configuration via API"""
    config_data = request.json
    if hatching_service.set_configuration(config_data):
        return jsonify({"success": True, "message": "Configuration updated successfully"})
    else:
        return jsonify({"success": False, "message": "Failed to update configuration"}), 400

@app.route('/api/service/mode', methods=['POST'])
@require_api_auth
def api_set_mode(user_id):
    """Set the hatching mode via API"""
    mode = request.json.get('mode')
    if mode is None:
        return jsonify({"success": False, "message": "Mode is required"}), 400
    
    if hatching_service.set_mode(mode):
        return jsonify({"success": True, "message": f"Mode set to {mode}"})
    else:
        return jsonify({"success": False, "message": "Failed to set mode"}), 500

# Main entry point
if __name__ == "__main__":
    # Use Gevent WSGI server for production
    http_server = WSGIServer(('0.0.0.0', 5000), app)
    print("Starting server on http://0.0.0.0:5000")
    http_server.serve_forever()