/**
 * PS99 Mining Bot - Overlay Script
 * Handles draggable functionality and always-on-top behavior
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize Feather icons
    if (typeof feather !== 'undefined') {
        feather.replace();
    }
    
    // Make the overlay draggable
    makeDraggable(document.getElementById('overlay'), document.getElementById('dragHandle'));
    
    // Minimize button functionality
    const minimizeBtn = document.getElementById('minimizeToggle');
    const overlay = document.getElementById('overlay');
    const minimizedIcon = 'maximize';
    const expandedIcon = 'minus';
    
    if (minimizeBtn) {
        minimizeBtn.addEventListener('click', function() {
            overlay.classList.toggle('overlay-minimized');
            
            // Update the icon
            const iconElement = minimizeBtn.querySelector('i');
            if (overlay.classList.contains('overlay-minimized')) {
                iconElement.setAttribute('data-feather', minimizedIcon);
            } else {
                iconElement.setAttribute('data-feather', expandedIcon);
            }
            
            // Re-initialize Feather icons
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
        });
    }
    
    // Pin/unpin button functionality
    const pinBtn = document.getElementById('pinToggle');
    const pinnedIcon = 'pin-off';
    const unpinnedIcon = 'pin';
    
    if (pinBtn) {
        pinBtn.addEventListener('click', function() {
            overlay.classList.toggle('overlay-pin');
            
            // Update the icon
            const iconElement = pinBtn.querySelector('i');
            if (overlay.classList.contains('overlay-pin')) {
                iconElement.setAttribute('data-feather', pinnedIcon);
            } else {
                iconElement.setAttribute('data-feather', unpinnedIcon);
            }
            
            // Re-initialize Feather icons
            if (typeof feather !== 'undefined') {
                feather.replace();
            }
            
            // Save the pin state to localStorage
            localStorage.setItem('ps99_overlay_pinned', overlay.classList.contains('overlay-pin'));
        });
    }
    
    // Restore pin state from localStorage
    const isPinned = localStorage.getItem('ps99_overlay_pinned');
    if (isPinned === 'false') {
        overlay.classList.remove('overlay-pin');
        pinBtn.querySelector('i').setAttribute('data-feather', unpinnedIcon);
        feather.replace();
    }
    
    // Start button functionality
    const startBtn = document.getElementById('startButton');
    const stopBtn = document.getElementById('stopButton');
    
    if (startBtn) {
        startBtn.addEventListener('click', function() {
            // Get the last used settings from sessionStorage
            const priority = sessionStorage.getItem('ps99_priority') || 'balanced';
            const serverType = sessionStorage.getItem('ps99_server_type') || 'private';
            const enableServerSwitching = sessionStorage.getItem('ps99_enable_server_switching') === 'true';
            const serverSwitchInterval = parseInt(sessionStorage.getItem('ps99_server_switch_interval')) || 30;
            const enableMineAll = sessionStorage.getItem('ps99_enable_mine_all') === 'true';
            
            // Disable start button
            startBtn.disabled = true;
            startBtn.innerHTML = '<i data-feather="loader" class="spinner"></i>';
            
            // Start mining with the saved settings
            fetch('/api/start_mining', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    priority: priority,
                    server_type: serverType,
                    enable_server_switching: enableServerSwitching,
                    server_switch_interval: serverSwitchInterval,
                    mine_all_mode: enableMineAll
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showOverlayNotification('Mining started successfully!', 'success');
                    updateOverlayStatus(true);
                } else {
                    showOverlayNotification('Failed to start mining: ' + data.message, 'danger');
                    startBtn.disabled = false;
                    startBtn.innerHTML = '<i data-feather="play"></i> Start';
                    feather.replace();
                }
            })
            .catch(error => {
                console.error('Error starting mining:', error);
                showOverlayNotification('Error connecting to server', 'danger');
                startBtn.disabled = false;
                startBtn.innerHTML = '<i data-feather="play"></i> Start';
                feather.replace();
            });
        });
    }
    
    // Stop button functionality
    if (stopBtn) {
        stopBtn.addEventListener('click', function() {
            // Disable stop button
            stopBtn.disabled = true;
            stopBtn.innerHTML = '<i data-feather="loader" class="spinner"></i>';
            
            // Stop mining
            fetch('/api/stop_mining', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showOverlayNotification('Mining stopped successfully!', 'success');
                    updateOverlayStatus(false);
                } else {
                    showOverlayNotification('Failed to stop mining: ' + data.message, 'danger');
                    stopBtn.disabled = false;
                    stopBtn.innerHTML = '<i data-feather="square"></i> Stop';
                    feather.replace();
                }
            })
            .catch(error => {
                console.error('Error stopping mining:', error);
                showOverlayNotification('Error connecting to server', 'danger');
                stopBtn.disabled = false;
                stopBtn.innerHTML = '<i data-feather="square"></i> Stop';
                feather.replace();
            });
        });
    }
    
    // Switch server button functionality
    const switchServerBtn = document.getElementById('switchServerButton');
    
    if (switchServerBtn) {
        switchServerBtn.addEventListener('click', function() {
            // Toggle server type
            const currentType = document.getElementById('serverType').textContent.toLowerCase().trim();
            const newType = currentType === 'private' ? 'public' : 'private';
            
            // Disable button
            switchServerBtn.disabled = true;
            switchServerBtn.innerHTML = '<i data-feather="loader" class="spinner"></i>';
            
            // Switch server
            fetch('/api/switch_server', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    server_type: newType
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showOverlayNotification(`Switched to ${newType} server`, 'success');
                    document.getElementById('serverType').textContent = newType;
                } else {
                    showOverlayNotification('Failed to switch server', 'danger');
                }
                switchServerBtn.disabled = false;
                switchServerBtn.innerHTML = '<i data-feather="refresh-cw"></i> Switch Server';
                feather.replace();
            })
            .catch(error => {
                console.error('Error switching server:', error);
                showOverlayNotification('Error connecting to server', 'danger');
                switchServerBtn.disabled = false;
                switchServerBtn.innerHTML = '<i data-feather="refresh-cw"></i> Switch Server';
                feather.replace();
            });
        });
    }
    
    // Check if Roblox is running (simulated)
    checkForRoblox();
    
    // Start updating overlay stats
    updateOverlayStats();
    setInterval(updateOverlayStats, 2000);
    
    // Check mining status on load
    checkMiningStatus();
});

/**
 * Make an element draggable 
 */
function makeDraggable(element, dragHandle) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    
    if (dragHandle) {
        // If a drag handle is specified, attach the listeners to it
        dragHandle.onmousedown = dragMouseDown;
    } else {
        // Otherwise, attach the listeners to the element itself
        element.onmousedown = dragMouseDown;
    }
    
    function dragMouseDown(e) {
        e = e || window.event;
        e.preventDefault();
        
        // Get the mouse cursor position at startup
        pos3 = e.clientX;
        pos4 = e.clientY;
        
        document.onmouseup = closeDragElement;
        // Call a function whenever the cursor moves
        document.onmousemove = elementDrag;
    }
    
    function elementDrag(e) {
        e = e || window.event;
        e.preventDefault();
        
        // Calculate the new cursor position
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        
        // Set the element's new position
        element.style.top = (element.offsetTop - pos2) + "px";
        element.style.left = (element.offsetLeft - pos1) + "px";
    }
    
    function closeDragElement() {
        // Stop moving when mouse button is released
        document.onmouseup = null;
        document.onmousemove = null;
        
        // Save position to localStorage
        localStorage.setItem('ps99_overlay_position_x', element.style.left);
        localStorage.setItem('ps99_overlay_position_y', element.style.top);
    }
    
    // Restore position from localStorage
    const savedX = localStorage.getItem('ps99_overlay_position_x');
    const savedY = localStorage.getItem('ps99_overlay_position_y');
    
    if (savedX && savedY) {
        element.style.left = savedX;
        element.style.top = savedY;
    } else {
        // Default position (top right)
        element.style.top = "20px";
        element.style.right = "20px";
    }
}

/**
 * Show a notification in the overlay
 */
function showOverlayNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `overlay-notification alert alert-${type} alert-dismissible fade show`;
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    // Add to body
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 150);
    }, 3000);
}

/**
 * Check if Roblox is running (simulated for demo)
 */
function checkForRoblox() {
    // In a real implementation, this would use the Node.js child_process 
    // module to check if the Roblox process is running
    console.log("Checking if Roblox is running...");
    
    // Simulated detection - in a real implementation, this would
    // check if the Roblox process exists and is in the foreground
    return true;
}

/**
 * Update the overlay status based on mining state
 */
function updateOverlayStatus(isRunning) {
    const startButton = document.getElementById('startButton');
    const stopButton = document.getElementById('stopButton');
    const statusIndicator = document.getElementById('miningStatus');
    
    if (startButton && stopButton && statusIndicator) {
        if (isRunning) {
            startButton.disabled = true;
            stopButton.disabled = false;
            statusIndicator.textContent = 'Running';
            statusIndicator.className = 'badge bg-success';
        } else {
            startButton.disabled = false;
            stopButton.disabled = true;
            statusIndicator.textContent = 'Stopped';
            statusIndicator.className = 'badge bg-secondary';
        }
        
        // Update button icons
        startButton.innerHTML = '<i data-feather="play"></i> Start';
        stopButton.innerHTML = '<i data-feather="square"></i> Stop';
        
        // Re-initialize Feather icons
        if (typeof feather !== 'undefined') {
            feather.replace();
        }
    }
}

/**
 * Update overlay stats
 */
function updateOverlayStats() {
    fetch('/api/get_stats')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const stats = data.stats;
                
                // Update mining status
                if (document.getElementById('miningStatus')) {
                    const status = document.getElementById('miningStatus');
                    if (stats.started_at) {
                        status.textContent = 'Running';
                        status.className = 'badge bg-success';
                    } else {
                        status.textContent = 'Stopped';
                        status.className = 'badge bg-secondary';
                    }
                }
                
                // Update priority
                if (document.getElementById('miningPriority')) {
                    document.getElementById('miningPriority').textContent = 
                        stats.priority ? stats.priority.charAt(0).toUpperCase() + stats.priority.slice(1) : 'Balanced';
                }
                
                // Update mine all mode
                if (document.getElementById('mineAllMode')) {
                    const mineAllModeElement = document.getElementById('mineAllMode');
                    if (stats.mine_all_mode) {
                        mineAllModeElement.textContent = 'Enabled';
                        mineAllModeElement.className = 'badge bg-success';
                    } else {
                        mineAllModeElement.textContent = 'Disabled';
                        mineAllModeElement.className = 'badge bg-secondary';
                    }
                }
                
                // Update server type
                if (document.getElementById('serverType')) {
                    document.getElementById('serverType').textContent = 
                        stats.server_type ? stats.server_type.charAt(0).toUpperCase() + stats.server_type.slice(1) : 'Private';
                }
                
                // Update mining rate
                if (document.getElementById('miningRate')) {
                    document.getElementById('miningRate').textContent = `${stats.mining_rate || 0} /min`;
                }
                
                // Update total mined
                if (document.getElementById('totalMined')) {
                    document.getElementById('totalMined').textContent = stats.total_resources || 0;
                }
            }
        })
        .catch(error => {
            console.error('Error fetching stats:', error);
        });
}

/**
 * Check if the mining bot is currently running
 */
function checkMiningStatus() {
    fetch('/api/check_status')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                updateOverlayStatus(data.is_running);
            }
        })
        .catch(error => {
            console.error('Error checking status:', error);
        });
}