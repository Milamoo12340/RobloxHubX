// User Scan JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Form submission handler
    const userScanForm = document.getElementById('user-scan-form');
    const usernameInput = document.getElementById('username');
    const userIdInput = document.getElementById('user-id');
    const scanButton = document.getElementById('scan-button');
    const scanSpinner = document.getElementById('scan-spinner');
    const scanResults = document.getElementById('scan-results');
    
    userScanForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = usernameInput.value.trim();
        const userId = userIdInput.value.trim();
        
        if (!username && !userId) {
            showAlert('Please enter a username or user ID', 'danger');
            return;
        }
        
        // Show loading state
        scanButton.disabled = true;
        scanSpinner.classList.remove('d-none');
        scanResults.innerHTML = '<div class="text-center"><p>Scanning user profile...</p></div>';
        
        // Make the API request
        fetch('/api/scan-user', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                user_id: userId
            })
        })
        .then(response => response.json())
        .then(data => {
            // Reset loading state
            scanButton.disabled = false;
            scanSpinner.classList.add('d-none');
            
            if (data.success) {
                displayScanResults(data.results);
            } else {
                showAlert(data.error || 'Failed to scan user profile', 'danger');
            }
        })
        .catch(error => {
            // Reset loading state
            scanButton.disabled = false;
            scanSpinner.classList.add('d-none');
            
            console.error('Error scanning user:', error);
            showAlert('An error occurred while scanning the user profile', 'danger');
        });
    });
    
    // Function to display scan results
    function displayScanResults(results) {
        const userInfo = results.user_info;
        const assets = results.assets;
        
        // Build the HTML for the results
        let html = `
            <div class="mb-4">
                <h4>User Information</h4>
                <div class="d-flex align-items-center mb-3">
                    <img src="https://www.roblox.com/headshot-thumbnail/image?userId=${userInfo.id}&width=150&height=150" 
                        alt="${userInfo.name}" class="me-3 rounded" style="width: 75px; height: 75px;">
                    <div>
                        <h5>${userInfo.name}</h5>
                        <p class="text-muted">User ID: ${userInfo.id}</p>
                    </div>
                </div>
            </div>
        `;
        
        // Display assets
        html += `<h4>Assets Found (${Object.keys(assets).length})</h4>`;
        
        if (Object.keys(assets).length > 0) {
            html += '<div class="row">';
            
            for (const [assetId, assetInfo] of Object.entries(assets)) {
                const assetType = assetInfo.assetType ? assetInfo.assetType.name : 'Unknown';
                const assetTypeClass = getAssetTypeClass(assetType);
                
                html += `
                    <div class="col-md-6 mb-3">
                        <div class="card bg-dark asset-card">
                            <div class="card-body">
                                <h5 class="card-title">${assetInfo.name}</h5>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge ${assetTypeClass}">${assetType}</span>
                                    <small class="text-muted">ID: ${assetId}</small>
                                </div>
                                <p class="card-text small">Created: ${new Date(assetInfo.created).toLocaleString()}</p>
                                <button class="btn btn-sm btn-primary" 
                                    onclick="downloadAsset(${assetId}, ${assetInfo.assetType ? assetInfo.assetType.id : 0})">
                                    Download Asset
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }
            
            html += '</div>';
        } else {
            html += '<p>No assets found for this user.</p>';
        }
        
        scanResults.innerHTML = html;
    }
    
    // Helper function to get the appropriate CSS class for an asset type
    function getAssetTypeClass(assetType) {
        const type = assetType.toLowerCase();
        if (type.includes('model')) return 'badge-model';
        if (type.includes('mesh')) return 'badge-mesh';
        if (type.includes('image') || type.includes('decal')) return 'badge-image';
        if (type.includes('audio') || type.includes('sound')) return 'badge-audio';
        return 'bg-secondary';
    }
    
    // Helper function to show alerts
    function showAlert(message, type) {
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        scanResults.innerHTML = alertHtml + scanResults.innerHTML;
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            const alertElement = scanResults.querySelector('.alert');
            if (alertElement) {
                alertElement.remove();
            }
        }, 5000);
    }
});

// Function to fill the username field from suggestions
function fillUserField(username) {
    document.getElementById('username').value = username;
    document.getElementById('user-id').value = '';
}

// Function to download an asset (this will be called from the results)
function downloadAsset(assetId, assetTypeId) {
    fetch('/api/download-asset', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            asset_id: assetId,
            asset_type: assetTypeId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Asset downloaded to: ${data.file_path}`);
        } else {
            alert(`Error: ${data.error}`);
        }
    })
    .catch(error => {
        console.error('Error downloading asset:', error);
        alert('An error occurred while downloading the asset');
    });
}