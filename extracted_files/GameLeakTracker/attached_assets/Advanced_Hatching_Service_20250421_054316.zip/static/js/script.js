document.addEventListener('DOMContentLoaded', function() {
    // Check if we're on the index page with the manual input form
    const submitManualDataBtn = document.getElementById('submitManualData');
    const manualDataTextarea = document.getElementById('manualData');
    const manualInputStatus = document.getElementById('manualInputStatus');
    
    if (submitManualDataBtn && manualDataTextarea) {
        submitManualDataBtn.addEventListener('click', function() {
            // Get the data from the textarea
            const jsonText = manualDataTextarea.value.trim();
            
            if (!jsonText) {
                showManualInputStatus('Please enter some data', true);
                return;
            }
            
            // Try to parse it as JSON
            try {
                const jsonData = JSON.parse(jsonText);
                
                // Send the data to our server
                fetch('/manual-input', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(jsonData)
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showManualInputStatus('Data submitted successfully!');
                        
                        // Redirect to results page after a short delay
                        setTimeout(() => {
                            window.location.href = '/results';
                        }, 1500);
                    } else {
                        showManualInputStatus('Error: ' + data.error, true);
                    }
                })
                .catch(error => {
                    showManualInputStatus('Error sending data to server: ' + error.message, true);
                });
            } catch (e) {
                showManualInputStatus('Invalid JSON: ' + e.message, true);
            }
        });
    }
    
    function showManualInputStatus(message, isError = false) {
        if (manualInputStatus) {
            manualInputStatus.textContent = message;
            manualInputStatus.className = isError ? 'alert alert-danger mt-3' : 'alert alert-success mt-3';
            manualInputStatus.style.display = 'block';
        }
    }
});