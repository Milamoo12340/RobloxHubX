// Loading script for PS99 Script Manager

// Random loading tips related to PS99
const loadingTips = [
  "Tip: The Slime Factory scripts can increase your profits by up to 300%!",
  "Tip: Use TNT strategically in mining areas for maximum gem collection.",
  "Tip: Key fragments appear more frequently in busy servers.",
  "Tip: The Ultimate Mining Optimizer automatically adapts to Triple Points events.",
  "Tip: Stealth Mode helps prevent detection by using variable click patterns.",
  "Tip: The 'Speed Focus' upgrade strategy works best for early Slime Factory progress.",
  "Tip: Combining 5+ key fragments at once increases your chances of legendary keys.",
  "Tip: You can use F3 to instantly stop any running script.",
  "Tip: Don't forget to set your Roblox username in Settings.",
  "Tip: The overlay can be hidden by unchecking 'Show Overlay' in Settings.",
  "Tip: Mining scripts work in both windowed and fullscreen mode.",
  "Tip: Check for new scripts weekly - we're constantly adding more!",
  "Tip: Most scripts work in the background while you do other things.",
  "Tip: The application automatically checks for updates on startup.",
  "Tip: Configure your script settings before running for best results."
];

// Elements
const loadingBar = document.getElementById('loadingBar');
const loadingTip = document.getElementById('loadingTip');

// Initialize loading sequence
document.addEventListener('DOMContentLoaded', () => {
  // Start with random tip
  setRandomTip();
  
  // Change tip every 5 seconds
  setInterval(setRandomTip, 5000);
  
  // Start progress animation
  startLoadingAnimation();
  
  // Simulate loading for the web demo
  simulateLoading();
});

// Set a random tip from our collection
function setRandomTip() {
  const randomIndex = Math.floor(Math.random() * loadingTips.length);
  
  // Fade out current tip
  loadingTip.style.opacity = '0';
  
  // After fade out, change text and fade back in
  setTimeout(() => {
    loadingTip.textContent = loadingTips[randomIndex];
    loadingTip.style.opacity = '1';
  }, 500);
}

// Start the mascot animations (additional interactive elements)
function animateMascot() {
  const mascotElement = document.getElementById('mascot');
  
  // Add event listener to make the mascot react to mouse hover
  mascotElement.addEventListener('mouseenter', () => {
    // Make the mascot excited when hovered
    mascotElement.classList.add('excited');
    
    // Play a sound if available
    playSound('hover');
  });
  
  // Remove excited state when mouse leaves
  mascotElement.addEventListener('mouseleave', () => {
    mascotElement.classList.remove('excited');
  });
  
  // Make the mascot react to clicks
  mascotElement.addEventListener('click', () => {
    // Add jump animation class
    mascotElement.classList.add('jump');
    
    // Play a sound if available
    playSound('click');
    
    // Remove jump class after animation completes
    setTimeout(() => {
      mascotElement.classList.remove('jump');
    }, 1000);
  });
}

// Play sound effect with the given name
function playSound(soundName) {
  console.log(`Playing sound: ${soundName}`);
  
  // Sound effect definitions (would normally be audio files)
  const sounds = {
    'click': {
      frequency: 800,
      type: 'square',
      duration: 80,
      volume: 0.2
    },
    'hover': {
      frequency: 300,
      type: 'sawtooth',
      duration: 120,
      volume: 0.08
    },
    'meow': {
      frequency: 500,
      type: 'sine',
      duration: 300,
      volume: 0.15,
      slide: 700
    },
    'purr': {
      frequency: 200,
      type: 'sine',
      duration: 500,
      volume: 0.15,
      modulation: 20
    },
    'bark': {
      frequency: 100,
      type: 'square',
      duration: 150,
      volume: 0.15
    },
    'roar': {
      frequency: 100,
      type: 'sawtooth',
      duration: 500,
      volume: 0.2,
      slide: 50
    }
  };
  
  // Get sound config or use default click sound
  const sound = sounds[soundName] || sounds.click;
  
  try {
    // Create audio context
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const audioCtx = new AudioContext();
    
    // Create oscillator
    const oscillator = audioCtx.createOscillator();
    oscillator.type = sound.type;
    oscillator.frequency.setValueAtTime(sound.frequency, audioCtx.currentTime);
    
    // Add frequency slide if specified
    if (sound.slide) {
      oscillator.frequency.linearRampToValueAtTime(
        sound.slide, 
        audioCtx.currentTime + sound.duration / 1000
      );
    }
    
    // Add frequency modulation if specified
    if (sound.modulation) {
      setInterval(() => {
        oscillator.frequency.setValueAtTime(
          sound.frequency + Math.random() * sound.modulation, 
          audioCtx.currentTime
        );
      }, 50);
    }
    
    // Create gain node for volume control
    const gainNode = audioCtx.createGain();
    gainNode.gain.setValueAtTime(sound.volume, audioCtx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + sound.duration / 1000);
    
    // Connect nodes
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    
    // Play sound
    oscillator.start();
    oscillator.stop(audioCtx.currentTime + sound.duration / 1000);
  } catch (e) {
    console.log('Sound playback failed:', e);
    // Fallback to no sound for browsers that don't support Web Audio API
  }
}

// Start the loading animation
function startLoadingAnimation() {
  // Initialize the progress bar at 0%
  updateLoadingProgress(0);
  
  // Start mascot animations
  animateMascot();
}

// Update the loading progress bar
function updateLoadingProgress(percent) {
  loadingBar.style.width = `${percent}%`;
  loadingBar.setAttribute('aria-valuenow', percent);
  
  // When progress reaches 100%, prepare for completion
  if (percent >= 100) {
    prepareForCompletion();
  }
}

// Simulate loading progress (for the web demo)
function simulateLoading() {
  let progress = 0;
  const interval = setInterval(() => {
    progress += Math.floor(Math.random() * 3) + 1;
    
    if (progress > 100) {
      progress = 100;
      clearInterval(interval);
      
      // After a short delay, complete the loading
      setTimeout(completeLoading, 1000);
    }
    
    updateLoadingProgress(progress);
  }, 200);
}

// Prepare UI for completion
function prepareForCompletion() {
  // Add a complete class to the loading container
  document.querySelector('.loading-container').classList.add('complete');
  
  // Change loading message
  document.querySelector('.loading-message').textContent = 'Ready to launch!';
}

// Complete the loading process
function completeLoading() {
  // For the demo, redirect back to the main index page
  setTimeout(() => {
    document.querySelector('.loading-message').textContent = 'Loading complete!';
    
    // Redirect back to home after a delay
    setTimeout(() => {
      window.location.href = '/';
    }, 2000);
  }, 1000);
}

// Add some extra interactive animations to make the loading screen more playful
function addExtraAnimations() {
  // Create floating particles in the background
  createFloatingParticles();
  
  // Make the gems react to mouse movement
  makeGemsInteractive();
  
  // Make pets interactive
  makePetsInteractive();
  
  // Make avatar interactive
  makeAvatarInteractive();
}

// Create floating particle effects in the background
function createFloatingParticles() {
  const container = document.querySelector('.loading-screen');
  
  // Create 15 particles
  for (let i = 0; i < 15; i++) {
    const particle = document.createElement('div');
    particle.className = 'floating-particle';
    
    // Random position
    const posX = Math.random() * 100;
    const posY = Math.random() * 100;
    
    // Random size
    const size = Math.random() * 5 + 2;
    
    // Random animation duration
    const duration = Math.random() * 20 + 10;
    
    // Set styles
    particle.style.left = `${posX}%`;
    particle.style.top = `${posY}%`;
    particle.style.width = `${size}px`;
    particle.style.height = `${size}px`;
    particle.style.animationDuration = `${duration}s`;
    
    // Add to container
    container.appendChild(particle);
  }
}

// Make gems react to mouse movement
function makeGemsInteractive() {
  const gems = document.querySelectorAll('.gem');
  const container = document.querySelector('.loading-screen');
  
  container.addEventListener('mousemove', (e) => {
    // Get mouse position relative to the container
    const mouseX = e.clientX;
    const mouseY = e.clientY;
    
    // Make each gem rotate slightly based on mouse position
    gems.forEach((gem, index) => {
      const offsetX = (mouseX / window.innerWidth - 0.5) * 20;
      const offsetY = (mouseY / window.innerHeight - 0.5) * 20;
      
      // Apply transform with slight delay for each gem
      setTimeout(() => {
        gem.style.transform = `rotate(${offsetX}deg) translateX(${offsetY}px)`;
      }, index * 50);
    });
  });
}

// Make pets interactive with click and hover effects
function makePetsInteractive() {
  const petCat = document.querySelector('.pet-cat');
  const petDog = document.querySelector('.pet-dog');
  const petDragon = document.querySelector('.pet-dragon');
  
  // Cat interactions
  if (petCat) {
    petCat.addEventListener('mouseenter', () => {
      // Show cat is happy when hovered
      const mouth = petCat.querySelector('.pet-mouth');
      if (mouth) {
        mouth.setAttribute('d', 'M-10,5 Q0,10 10,5');
      }
      
      // Play sound
      playSound('meow');
    });
    
    petCat.addEventListener('mouseleave', () => {
      // Return to normal expression
      const mouth = petCat.querySelector('.pet-mouth');
      if (mouth) {
        mouth.setAttribute('d', 'M-10,5 Q0,12 10,5');
      }
    });
    
    petCat.addEventListener('click', () => {
      // Make the cat jump higher on click
      petCat.style.animation = 'none';
      setTimeout(() => {
        petCat.style.animation = 'cat-excited 1s ease-in-out';
        
        // Return to normal animation after effect
        setTimeout(() => {
          petCat.style.animation = 'pet-bounce 3s ease-in-out infinite';
        }, 1000);
      }, 10);
      
      // Play sound
      playSound('purr');
    });
  }
  
  // Dog interactions
  if (petDog) {
    petDog.addEventListener('mouseenter', () => {
      // Show dog is excited when hovered
      petDog.style.animation = 'pet-wag 0.5s ease-in-out infinite';
    });
    
    petDog.addEventListener('mouseleave', () => {
      // Return to normal animation
      petDog.style.animation = 'pet-wag 2s ease-in-out infinite';
    });
    
    petDog.addEventListener('click', () => {
      // Make the dog bark
      const mouth = petDog.querySelector('.pet-mouth');
      if (mouth) {
        mouth.setAttribute('d', 'M-12,12 Q0,25 12,12');
        
        // Return to normal expression after effect
        setTimeout(() => {
          mouth.setAttribute('d', 'M-12,12 Q0,20 12,12');
        }, 300);
      }
      
      // Play sound
      playSound('bark');
    });
  }
  
  // Dragon interactions
  if (petDragon) {
    petDragon.addEventListener('mouseenter', () => {
      // Make gems glow brighter when hovered
      const gems = petDragon.querySelectorAll('.dragon-gem-1, .dragon-gem-2, .dragon-gem-3');
      gems.forEach(gem => {
        gem.style.filter = 'brightness(1.5)';
      });
    });
    
    petDragon.addEventListener('mouseleave', () => {
      // Return to normal gem brightness
      const gems = petDragon.querySelectorAll('.dragon-gem-1, .dragon-gem-2, .dragon-gem-3');
      gems.forEach(gem => {
        gem.style.filter = 'brightness(1)';
      });
    });
    
    petDragon.addEventListener('click', () => {
      // Make the dragon spin on click
      petDragon.style.animation = 'none';
      setTimeout(() => {
        petDragon.style.animation = 'dragon-spin 1s ease-in-out';
        
        // Return to normal animation after effect
        setTimeout(() => {
          petDragon.style.animation = 'pet-float 4s ease-in-out infinite';
        }, 1000);
      }, 10);
      
      // Play sound
      playSound('roar');
    });
  }
}

// Make PS99 pets interactive - these are actual pets from the screenshots
function makeGamePetsInteractive() {
  const ps99Pets = document.querySelectorAll('.ps99-pet');
  
  ps99Pets.forEach((pet, index) => {
    pet.addEventListener('mouseenter', () => {
      // Create glow effect around the pet
      pet.style.transform = 'scale(1.1)';
      pet.style.boxShadow = '0 0 15px rgba(255, 215, 0, 0.7)';
      
      // Make the pet value glow brighter
      const petValue = pet.querySelector('.pet-value');
      if (petValue) {
        petValue.style.animationDuration = '1s';
        petValue.style.boxShadow = '0 0 10px gold';
      }
      
      // Play pet sound based on type
      const petSounds = ['meow', 'purr', 'bark', 'roar'];
      playSound(petSounds[index % petSounds.length]);
    });
    
    pet.addEventListener('mouseleave', () => {
      // Remove glow effect
      pet.style.transform = '';
      pet.style.boxShadow = '';
      
      // Reset pet value animation
      const petValue = pet.querySelector('.pet-value');
      if (petValue) {
        petValue.style.animationDuration = '3s';
        petValue.style.boxShadow = '0 0 5px rgba(255, 215, 0, 0.5)';
      }
    });
    
    pet.addEventListener('click', () => {
      // Make pet jump when clicked
      pet.style.animation = 'none';
      setTimeout(() => {
        pet.style.animation = 'game-pet-float 5s ease-in-out infinite';
      }, 10);
      
      // Make pet pulse
      pet.style.transform = 'scale(0.95)';
      
      // Add a message about this rare pet
      const loadingMsg = document.querySelector('.loading-message');
      if (loadingMsg) {
        const originalMsg = loadingMsg.textContent;
        
        // Different messages for each pet based on game values from screenshots
        let petMessage;
        if (pet.id === 'ps99-pet-1') {
          petMessage = "Huge Cat: Worth 7,415 gems! Super rare mythical pet!";
        } else if (pet.id === 'ps99-pet-2') {
          petMessage = "Red Dominus: Worth 305 gems! A powerful companion!";
        } else if (pet.id === 'ps99-pet-3') {
          petMessage = "Green Slime: Worth 1,055 gems! Perfect for Slime Factory!";
        }
        
        loadingMsg.textContent = petMessage;
        
        // Return to original message after delay
        setTimeout(() => {
          loadingMsg.textContent = originalMsg;
        }, 3000);
      }
      
      // Make tip about the pet
      const loadingTip = document.querySelector('#loadingTip');
      if (loadingTip && Math.random() > 0.5) {
        const originalTip = loadingTip.textContent;
        
        let petTip;
        if (pet.id === 'ps99-pet-1') {
          petTip = "Tip: Huge pets like this provide 3x the power in mining and tycoons!";
        } else if (pet.id === 'ps99-pet-2') {
          petTip = "Tip: Dominus pets are extremely rare and boost luck by 50%!";
        } else if (pet.id === 'ps99-pet-3') {
          petTip = "Tip: Slime pets get a special bonus in the Slime Factory tycoon!";
        }
        
        loadingTip.style.opacity = '0';
        setTimeout(() => {
          loadingTip.textContent = petTip;
          loadingTip.style.opacity = '1';
        }, 500);
        
        // Return to original tip after delay
        setTimeout(() => {
          loadingTip.style.opacity = '0';
          setTimeout(() => {
            loadingTip.textContent = originalTip;
            loadingTip.style.opacity = '1';
          }, 500);
        }, 4000);
      }
      
      // Play special sound
      playSound('roar');
      
      // Return to normal after effect
      setTimeout(() => {
        pet.style.transform = '';
      }, 500);
    });
  });
}

// Make avatar interactive with spider behaviors
function makeAvatarInteractive() {
  const avatar = document.querySelector('.player-avatar');
  
  if (avatar) {
    avatar.addEventListener('mouseenter', () => {
      // Create a red glow effect around the avatar for spider theme
      avatar.style.filter = 'drop-shadow(0 0 8px rgba(196, 30, 58, 0.8))';
      
      // Make spider legs wiggle faster on hover
      const legs = avatar.querySelectorAll('.spider-leg');
      legs.forEach(leg => {
        leg.style.animationDuration = '0.8s';
      });
      
      // Make red stripe pulse faster
      const stripe = avatar.querySelector('.spider-stripe');
      if (stripe) {
        stripe.style.animationDuration = '1s';
      }
      
      // Play spider hiss sound
      playSound('hover');
    });
    
    avatar.addEventListener('mouseleave', () => {
      // Remove glow effect
      avatar.style.filter = '';
      
      // Reset spider legs animation speed
      const legs = avatar.querySelectorAll('.spider-leg');
      legs.forEach(leg => {
        leg.style.animationDuration = '2s';
      });
      
      // Reset red stripe pulse
      const stripe = avatar.querySelector('.spider-stripe');
      if (stripe) {
        stripe.style.animationDuration = '4s';
      }
    });
    
    avatar.addEventListener('click', () => {
      // Spider attack animation when clicked
      avatar.style.animation = 'none';
      setTimeout(() => {
        // Make spider jump forward slightly
        avatar.style.animation = 'spider-attack 0.7s ease-in-out';
        
        // Make legs move rapidly during attack
        const legs = avatar.querySelectorAll('.spider-leg');
        legs.forEach(leg => {
          leg.style.animationDuration = '0.3s';
        });
        
        // Make spikes twitch rapidly
        const spikes = avatar.querySelectorAll('.spike');
        spikes.forEach(spike => {
          spike.style.animationDuration = '0.5s';
        });
        
        // Return to normal animation after effect
        setTimeout(() => {
          avatar.style.animation = 'avatar-creep 6s ease-in-out infinite';
          
          // Reset leg animation
          legs.forEach(leg => {
            leg.style.animationDuration = '2s';
          });
          
          // Reset spike animation
          spikes.forEach(spike => {
            spike.style.animationDuration = '4s';
          });
        }, 700);
      }, 10);
      
      // Add special spider-themed message
      const loadingMsg = document.querySelector('.loading-message');
      if (loadingMsg) {
        const originalMsg = loadingMsg.textContent;
        loadingMsg.textContent = "The Black Widow Queen is ready for PS99 domination!";
        
        // Return to loading message after a delay
        setTimeout(() => {
          loadingMsg.textContent = originalMsg;
        }, 2500);
      }
      
      // Add special loading tip
      const loadingTip = document.querySelector('#loadingTip');
      if (loadingTip && Math.random() > 0.5) {
        const originalTip = loadingTip.textContent;
        loadingTip.textContent = "Tip: Your spider avatar has special powers in the Slime Factory!";
        
        // Return to original tip after a delay
        setTimeout(() => {
          loadingTip.textContent = originalTip;
        }, 3500);
      }
      
      // Play sound
      playSound('click');
    });
  }
}

// Add extra CSS for spider attack animation
function addSpiderStyles() {
  const styleSheet = document.createElement("style");
  styleSheet.type = "text/css";
  styleSheet.innerText = `
    @keyframes spider-attack {
      0% {
        transform: translate(150px, 160px) scale(0.3);
      }
      40% {
        transform: translate(150px, 145px) scale(0.34);
      }
      60% {
        transform: translate(150px, 140px) scale(0.36);
      }
      100% {
        transform: translate(150px, 160px) scale(0.3);
      }
    }
  `;
  document.head.appendChild(styleSheet);
}

// Call the function to add spider styles
addSpiderStyles();

// Add extra CSS styles for new animations
function addExtraStyles() {
  const styleSheet = document.createElement("style");
  styleSheet.type = "text/css";
  styleSheet.innerText = `
    @keyframes cat-excited {
      0%, 100% {
        transform: translate(30px, 150px) scale(0.5);
      }
      50% {
        transform: translate(30px, 120px) scale(0.5);
      }
    }
    
    @keyframes dragon-spin {
      0% {
        transform: translate(40px, 40px) scale(0.35) rotate(0deg);
      }
      100% {
        transform: translate(40px, 40px) scale(0.35) rotate(360deg);
      }
    }
    
    @keyframes avatar-clicked {
      0%, 100% {
        transform: translate(150px, 160px) scale(0.4);
      }
      50% {
        transform: translate(150px, 160px) scale(0.5);
      }
    }
  `;
  document.head.appendChild(styleSheet);
}

// Call extra animations and add styles
addExtraStyles();
// Add game pet interactions
addExtraAnimations();
makeGamePetsInteractive();