// Main JavaScript for Advanced Hatching Service

document.addEventListener('DOMContentLoaded', function() {
    // Enable all tooltips
    const tooltips = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    tooltips.forEach(tooltip => {
        new bootstrap.Tooltip(tooltip);
    });

    // Add fade-in animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.classList.add('fade-in');
        }, index * 100);
    });

    // Handle service errors
    function handleServiceError(response) {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    }

    // Format numbers with commas
    function formatNumber(num) {
        return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,');
    }

    // Update UI elements with formatted numbers
    function updateFormattedNumbers() {
        const numberElements = document.querySelectorAll('.formatted-number');
        numberElements.forEach(element => {
            const value = parseInt(element.textContent.replace(/,/g, ''));
            if (!isNaN(value)) {
                element.textContent = formatNumber(value);
            }
        });
    }

    // Call initial formatting
    updateFormattedNumbers();

    // Handle form submission with AJAX
    const ajaxForms = document.querySelectorAll('.ajax-form');
    ajaxForms.forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(form);
            const url = form.getAttribute('action');
            const method = form.getAttribute('method') || 'POST';
            
            // Show loading indicator
            const submitButton = form.querySelector('[type="submit"]');
            if (submitButton) {
                const originalText = submitButton.innerHTML;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Loading...';
                submitButton.disabled = true;
            }
            
            // Convert FormData to JSON if needed
            const jsonData = {};
            formData.forEach((value, key) => {
                jsonData[key] = value;
            });
            
            // Send the request
            fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(jsonData)
            })
            .then(handleServiceError)
            .then(data => {
                if (data.success) {
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else if (data.message) {
                        showAlert('success', data.message);
                    }
                    
                    // Reset form if it has a data-reset attribute
                    if (form.hasAttribute('data-reset')) {
                        form.reset();
                    }
                    
                    // Trigger callback if specified
                    if (form.hasAttribute('data-callback')) {
                        const callback = form.getAttribute('data-callback');
                        if (typeof window[callback] === 'function') {
                            window[callback](data);
                        }
                    }
                } else {
                    showAlert('danger', data.message || 'An error occurred');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('danger', 'An error occurred while processing your request');
            })
            .finally(() => {
                // Restore submit button
                if (submitButton) {
                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                }
            });
        });
    });
    
    // Alert function
    function showAlert(type, message, duration = 5000) {
        const alertContainer = document.getElementById('alertContainer');
        if (!alertContainer) {
            // Create alert container if it doesn't exist
            const container = document.createElement('div');
            container.id = 'alertContainer';
            container.style.position = 'fixed';
            container.style.top = '20px';
            container.style.right = '20px';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }
        
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.role = 'alert';
        
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;
        
        document.getElementById('alertContainer').appendChild(alertDiv);
        
        // Auto-dismiss after duration
        setTimeout(() => {
            alertDiv.classList.remove('show');
            setTimeout(() => {
                alertDiv.remove();
            }, 150);
        }, duration);
    }
    
    // Handle status refresh for any status indicators
    function refreshStatus() {
        const statusIndicators = document.querySelectorAll('.status-refresh');
        if (statusIndicators.length > 0) {
            fetch('/service/status')
            .then(response => response.json())
            .then(data => {
                statusIndicators.forEach(indicator => {
                    const key = indicator.getAttribute('data-status-key');
                    if (key && key.includes('.')) {
                        // Handle nested keys like 'stats.total_hatches'
                        const keys = key.split('.');
                        let value = data;
                        for (const k of keys) {
                            value = value[k];
                        }
                        indicator.textContent = value;
                    } else if (key) {
                        indicator.textContent = data[key];
                    }
                });
                
                // Update formatted numbers
                updateFormattedNumbers();
            })
            .catch(error => {
                console.error('Status refresh error:', error);
            });
        }
    }
    
    // Set up status refresh interval if needed
    if (document.querySelectorAll('.status-refresh').length > 0) {
        setInterval(refreshStatus, 5000);
        refreshStatus(); // Initial refresh
    }
    
    // Handle confirmation dialogs
    const confirmButtons = document.querySelectorAll('[data-confirm]');
    confirmButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm(this.getAttribute('data-confirm'))) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            }
        });
    });
});