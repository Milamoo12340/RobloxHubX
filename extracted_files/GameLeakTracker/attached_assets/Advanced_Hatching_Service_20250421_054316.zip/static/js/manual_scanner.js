/**
 * PS99 Manual Scanner Manager
 * 
 * This script manages interactions with the PS99 unfiltered scanner
 * and provides functionality for starting/stopping scans and viewing results.
 */

class ManualScannerManager {
    constructor(options = {}) {
        // Default options
        this.options = Object.assign({
            statusElementId: 'scanStatus',
            progressElementId: 'scanProgress',
            resultsElementId: 'scanResults',
            startButtonId: 'startScanBtn',
            stopButtonId: 'stopScanBtn',
            statusCheckInterval: 3000, // Check status every 3 seconds
        }, options);
        
        // Status check timer
        this.statusCheckTimer = null;
        
        // Elements
        this.statusElement = document.getElementById(this.options.statusElementId);
        this.progressElement = document.getElementById(this.options.progressElementId);
        this.resultsElement = document.getElementById(this.options.resultsElementId);
        this.startButton = document.getElementById(this.options.startButtonId);
        this.stopButton = document.getElementById(this.options.stopButtonId);
        
        // Bind event handlers
        if (this.startButton) {
            this.startButton.addEventListener('click', this.startScan.bind(this));
        }
        if (this.stopButton) {
            this.stopButton.addEventListener('click', this.stopScan.bind(this));
        }
        
        // Check current status
        this.checkStatus();
    }
    
    /**
     * Updates the UI with the current scanner status
     */
    updateStatusUI(status) {
        if (!this.statusElement) return;
        
        // Update status message
        this.statusElement.textContent = status.message;
        
        // Update status classes
        this.statusElement.className = 'alert';
        if (status.status === 'idle') {
            this.statusElement.classList.add('alert-secondary');
        } else if (status.status === 'running') {
            this.statusElement.classList.add('alert-info');
        } else if (status.status === 'completed') {
            this.statusElement.classList.add('alert-success');
        } else if (status.status === 'error') {
            this.statusElement.classList.add('alert-danger');
        }
        
        // Update progress
        if (this.progressElement) {
            if (status.status === 'running') {
                this.progressElement.classList.remove('d-none');
                const percent = Math.min(100, Math.round((status.developers_scanned / status.total_developers) * 100));
                const progressBar = this.progressElement.querySelector('.progress-bar');
                if (progressBar) {
                    progressBar.style.width = `${percent}%`;
                    progressBar.setAttribute('aria-valuenow', percent);
                }
            } else {
                this.progressElement.classList.add('d-none');
            }
        }
        
        // Enable/disable buttons
        if (this.startButton) {
            this.startButton.disabled = status.status === 'running';
        }
        if (this.stopButton) {
            this.stopButton.disabled = status.status !== 'running';
        }
    }
    
    /**
     * Check the current scanner status
     */
    checkStatus() {
        fetch('/scanner/status')
            .then(response => response.json())
            .then(status => {
                this.updateStatusUI(status);
                
                // If scan is running, start periodic checks
                if (status.status === 'running' && !this.statusCheckTimer) {
                    this.statusCheckTimer = setInterval(() => {
                        this.checkStatus();
                    }, this.options.statusCheckInterval);
                } else if (status.status !== 'running' && this.statusCheckTimer) {
                    // If scan is not running, stop periodic checks
                    clearInterval(this.statusCheckTimer);
                    this.statusCheckTimer = null;
                }
            })
            .catch(error => {
                console.error('Error checking scan status:', error);
                if (this.statusElement) {
                    this.statusElement.className = 'alert alert-danger';
                    this.statusElement.textContent = `Error checking status: ${error.message}`;
                }
            });
    }
    
    /**
     * Start a scan with the provided options
     */
    startScan() {
        if (!this.startButton) return;
        
        // Get scan options from UI
        const chunkSize = document.getElementById('chunkSize') ? 
            parseInt(document.getElementById('chunkSize').value, 10) : 5;
        const maxChunks = document.getElementById('maxChunks') ? 
            parseInt(document.getElementById('maxChunks').value, 10) : 3;
        
        // Update UI
        this.startButton.disabled = true;
        if (this.statusElement) {
            this.statusElement.className = 'alert alert-info';
            this.statusElement.textContent = 'Starting scan...';
        }
        
        // Start scan
        fetch('/scanner/start', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                chunk_size: chunkSize,
                max_chunks: maxChunks
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (this.statusElement) {
                    this.statusElement.textContent = 'Scan started successfully!';
                }
                // Start checking status
                this.checkStatus();
            } else {
                if (this.statusElement) {
                    this.statusElement.className = 'alert alert-danger';
                    this.statusElement.textContent = `Error: ${data.message}`;
                }
                this.startButton.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error starting scan:', error);
            if (this.statusElement) {
                this.statusElement.className = 'alert alert-danger';
                this.statusElement.textContent = `Error starting scan: ${error.message}`;
            }
            this.startButton.disabled = false;
        });
    }
    
    /**
     * Stop a running scan
     */
    stopScan() {
        if (!this.stopButton) return;
        
        // Update UI
        this.stopButton.disabled = true;
        if (this.statusElement) {
            this.statusElement.className = 'alert alert-warning';
            this.statusElement.textContent = 'Stopping scan...';
        }
        
        // Stop scan
        fetch('/scanner/stop', {
            method: 'POST',
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                if (this.statusElement) {
                    this.statusElement.textContent = 'Scan stopped successfully!';
                }
                // Start checking status
                this.checkStatus();
            } else {
                if (this.statusElement) {
                    this.statusElement.className = 'alert alert-danger';
                    this.statusElement.textContent = `Error: ${data.message}`;
                }
                this.stopButton.disabled = false;
            }
        })
        .catch(error => {
            console.error('Error stopping scan:', error);
            if (this.statusElement) {
                this.statusElement.className = 'alert alert-danger';
                this.statusElement.textContent = `Error stopping scan: ${error.message}`;
            }
            this.stopButton.disabled = false;
        });
    }
    
    /**
     * Load scan results
     */
    loadResults() {
        if (!this.resultsElement) return;
        
        fetch('/scanner/results')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show results
                    this.resultsElement.classList.remove('d-none');
                    
                    // Update results UI
                    const resultsSummary = document.getElementById('resultsSummary');
                    if (resultsSummary) {
                        let summaryContent = '';
                        
                        if (data.db_stats.developers_scanned) {
                            summaryContent += `<div><strong>Developers Scanned:</strong> ${data.db_stats.developers_scanned}</div>`;
                        }
                        
                        if (data.db_stats.assets_found) {
                            summaryContent += `<div><strong>Assets Found:</strong> ${data.db_stats.assets_found}</div>`;
                        }
                        
                        if (data.last_modified) {
                            summaryContent += `<div><strong>Last Updated:</strong> ${data.last_modified}</div>`;
                        }
                        
                        resultsSummary.innerHTML = summaryContent;
                    }
                    
                    // Update latest assets
                    const latestAssets = document.getElementById('latestAssets');
                    if (latestAssets && data.db_stats.latest_assets) {
                        let assetListHTML = '';
                        
                        for (const asset of data.db_stats.latest_assets) {
                            assetListHTML += `
                                <div class="card mb-2">
                                    <div class="card-body">
                                        <h5 class="card-title">${asset.name || 'Unknown Asset'}</h5>
                                        <h6 class="card-subtitle mb-2 text-muted">ID: ${asset.asset_id || asset.id}</h6>
                                        <p class="card-text">${asset.description || 'No description available'}</p>
                                        <div class="text-end">
                                            <a href="https://www.roblox.com/catalog/${asset.asset_id || asset.id}" 
                                               target="_blank" class="btn btn-sm btn-primary">
                                                View on Roblox
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            `;
                        }
                        
                        latestAssets.innerHTML = assetListHTML;
                    }
                } else {
                    console.error('Error loading results:', data.message);
                }
            })
            .catch(error => {
                console.error('Error loading results:', error);
            });
    }
}

// Initialize scanner when document is ready
document.addEventListener('DOMContentLoaded', function() {
    window.scannerManager = new ManualScannerManager();
    
    // Load results button
    const loadResultsBtn = document.getElementById('loadResultsBtn');
    if (loadResultsBtn) {
        loadResultsBtn.addEventListener('click', function() {
            window.scannerManager.loadResults();
        });
    }
    
    // Auto-load results if results section is visible
    const resultsElement = document.getElementById('scanResults');
    if (resultsElement && !resultsElement.classList.contains('d-none')) {
        window.scannerManager.loadResults();
    }
});