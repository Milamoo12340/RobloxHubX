// PS99 Mining Path Visualizer
document.addEventListener('DOMContentLoaded', () => {
    // Mining grid visualization setup
    const miningGrid = document.getElementById('mining-grid');
    const gridWidth = miningGrid.offsetWidth;
    const gridHeight = miningGrid.offsetHeight;
    
    // Mining simulation state
    let simulationRunning = false;
    let simulationSpeed = 1.0;
    let resources = [];
    let miner = null;
    let pathLines = [];
    let miningPath = [];
    let currentPathIndex = 0;
    let targetIndicator = null;
    let animationFrame = null;
    let startTime = null;
    
    // Resource counters
    let resourceStats = {
        totalMined: 0,
        ores: { total: 0, common: 0, rare: 0, value: 0 },
        gems: { total: 0, common: 0, rare: 0, value: 0 },
        chests: { total: 0, common: 0, rare: 0, value: 0 },
        special: { total: 0, value: 0 },
        distance: 0,
        miningRate: 0,
        efficiency: 0,
        timeline: []
    };
    
    // Resource types and values
    const resourceTypes = ['ore', 'gem', 'chest', 'special'];
    const resourceColors = {
        ore: '#8B4513',
        gem: '#00FFFF',
        chest: '#FFD700',
        special: '#FF00FF'
    };
    const resourceValues = {
        ore: { common: 1, rare: 3 },
        gem: { common: 2, rare: 5 },
        chest: { common: 3, rare: 8 },
        special: { value: 10 }
    };
    
    // Resource timeline chart
    let timelineChart;
    
    // Minimap setup
    const minimap = document.querySelector('.minimap');
    const viewBox = document.querySelector('.view-box');
    const minimapScale = 150 / Math.max(gridWidth, gridHeight);
    
    // Initial setup function
    function initializeVisualizer() {
        setupTimelineChart();
        setupEventListeners();
        generateCoordinateLabels();
        generateResources();
        createMiner();
        calculateMiningPath();
        renderMinimap();
        updateStats();
    }
    
    // Set up the timeline chart
    function setupTimelineChart() {
        const ctx = document.getElementById('resourceTimeline').getContext('2d');
        timelineChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Ores',
                        data: [],
                        borderColor: '#8B4513',
                        backgroundColor: 'rgba(139, 69, 19, 0.2)',
                        tension: 0.1
                    },
                    {
                        label: 'Gems',
                        data: [],
                        borderColor: '#00FFFF',
                        backgroundColor: 'rgba(0, 255, 255, 0.2)',
                        tension: 0.1
                    },
                    {
                        label: 'Chests',
                        data: [],
                        borderColor: '#FFD700',
                        backgroundColor: 'rgba(255, 215, 0, 0.2)',
                        tension: 0.1
                    },
                    {
                        label: 'Special',
                        data: [],
                        borderColor: '#FF00FF',
                        backgroundColor: 'rgba(255, 0, 255, 0.2)',
                        tension: 0.1
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            color: 'white'
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            color: 'rgba(255, 255, 255, 0.7)'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: {
                            color: 'rgba(255, 255, 255, 0.7)'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                }
            }
        });
    }
    
    // Set up event listeners
    function setupEventListeners() {
        // Simulation control buttons
        document.getElementById('startSimulation').addEventListener('click', startSimulation);
        document.getElementById('pauseSimulation').addEventListener('click', pauseSimulation);
        document.getElementById('resetSimulation').addEventListener('click', resetSimulation);
        
        // View controls
        document.getElementById('enable3dView').addEventListener('change', toggle3DView);
        document.getElementById('showPathLines').addEventListener('change', togglePathLines);
        
        // Resource filters
        document.querySelectorAll('.resource-filter button').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.resource-filter button').forEach(b => b.classList.remove('active'));
                e.target.classList.add('active');
                filterResources(e.target.dataset.resource);
            });
        });
        
        // Simulation speed control
        const speedSlider = document.getElementById('simulationSpeed');
        const speedValue = document.getElementById('speedValue');
        
        speedSlider.addEventListener('input', () => {
            simulationSpeed = parseFloat(speedSlider.value);
            speedValue.textContent = `${simulationSpeed}x`;
        });
    }
    
    // Generate coordinate labels along the grid
    function generateCoordinateLabels() {
        // Add x-axis labels
        for (let x = 0; x <= gridWidth; x += 100) {
            const label = document.createElement('div');
            label.className = 'coordinate-label';
            label.style.left = `${x}px`;
            label.style.bottom = '0';
            label.textContent = `${x}`;
            miningGrid.appendChild(label);
        }
        
        // Add y-axis labels
        for (let y = 0; y <= gridHeight; y += 100) {
            const label = document.createElement('div');
            label.className = 'coordinate-label';
            label.style.left = '0';
            label.style.top = `${y}px`;
            label.textContent = `${y}`;
            miningGrid.appendChild(label);
        }
    }
    
    // Generate random resources on the grid
    function generateResources() {
        // Clear existing resources
        resources = [];
        document.querySelectorAll('.resource-node').forEach(node => node.remove());
        
        // Generate a mix of resources
        const resourceCounts = {
            ore: 25,
            gem: 18,
            chest: 12,
            special: 3
        };
        
        // Create resources based on counts
        for (const type in resourceCounts) {
            for (let i = 0; i < resourceCounts[type]; i++) {
                addResource(type);
            }
        }
        
        // Update progress bars
        updateResourceProgress();
    }
    
    // Add a single resource to the grid
    function addResource(type) {
        // Random position within the grid, with some padding
        const x = Math.random() * (gridWidth - 60) + 30;
        const y = Math.random() * (gridHeight - 60) + 30;
        
        // Random rarity (common vs rare)
        const isRare = Math.random() > 0.7;
        
        // Create the DOM element
        const resourceNode = document.createElement('div');
        resourceNode.className = `resource-node resource-${type}`;
        resourceNode.style.left = `${x}px`;
        resourceNode.style.top = `${y}px`;
        
        // Add a slight glow effect to rare items
        if (isRare && type !== 'special') {
            resourceNode.style.boxShadow = `0 0 15px ${resourceColors[type]}`;
            resourceNode.style.width = '24px';
            resourceNode.style.height = '24px';
        }
        
        // Add to the DOM
        miningGrid.appendChild(resourceNode);
        
        // Store resource data
        resources.push({
            type,
            rare: isRare,
            x,
            y,
            mined: false,
            element: resourceNode,
            value: isRare ? 
                (type === 'special' ? resourceValues.special.value : resourceValues[type].rare) :
                resourceValues[type].common
        });
        
        // Add to minimap
        addResourceToMinimap(x, y, type);
    }
    
    // Create the miner character
    function createMiner() {
        if (miner) {
            miner.element.remove();
        }
        
        const minerElement = document.createElement('div');
        minerElement.className = 'miner';
        
        // Start at a random position near the edge
        const startX = 30;
        const startY = 30;
        
        minerElement.style.left = `${startX}px`;
        minerElement.style.top = `${startY}px`;
        
        miningGrid.appendChild(minerElement);
        
        miner = {
            x: startX,
            y: startY,
            element: minerElement,
            mining: false
        };
        
        // Add miner to minimap
        addMinerToMinimap();
    }
    
    // Add a resource dot to the minimap
    function addResourceToMinimap(x, y, type) {
        const minimapDot = document.createElement('div');
        minimapDot.className = 'minimap-resource';
        minimapDot.style.backgroundColor = resourceColors[type];
        minimapDot.style.left = `${x * minimapScale}px`;
        minimapDot.style.top = `${y * minimapScale}px`;
        minimap.appendChild(minimapDot);
    }
    
    // Add miner dot to the minimap
    function addMinerToMinimap() {
        const minimapPlayer = document.createElement('div');
        minimapPlayer.className = 'minimap-player';
        minimapPlayer.id = 'minimap-player';
        minimapPlayer.style.left = `${miner.x * minimapScale}px`;
        minimapPlayer.style.top = `${miner.y * minimapScale}px`;
        minimap.appendChild(minimapPlayer);
    }
    
    // Update minimap view box position
    function updateMinimapViewBox() {
        const viewportWidth = gridWidth * 0.5;
        const viewportHeight = gridHeight * 0.5;
        
        // Calculate minimap view box position
        const centerX = miner.x;
        const centerY = miner.y;
        
        // Update minimap player position
        const minimapPlayer = document.getElementById('minimap-player');
        if (minimapPlayer) {
            minimapPlayer.style.left = `${centerX * minimapScale}px`;
            minimapPlayer.style.top = `${centerY * minimapScale}px`;
        }
        
        // Update viewbox dimensions and position
        viewBox.style.width = `${viewportWidth * minimapScale}px`;
        viewBox.style.height = `${viewportHeight * minimapScale}px`;
        viewBox.style.left = `${(centerX - viewportWidth / 2) * minimapScale}px`;
        viewBox.style.top = `${(centerY - viewportHeight / 2) * minimapScale}px`;
    }
    
    // Calculate the most efficient mining path
    function calculateMiningPath() {
        // Start with unmined resources only
        const availableResources = resources.filter(r => !r.mined);
        
        if (availableResources.length === 0) {
            return [];
        }
        
        // Start from miner's current position
        let currentX = miner.x;
        let currentY = miner.y;
        
        // Reset the path
        miningPath = [];
        
        // Simple greedy algorithm - find the nearest valuable resource
        while (availableResources.length > 0) {
            // Calculate distances to all resources
            const resourcesWithDistance = availableResources.map(r => {
                const distance = Math.sqrt(Math.pow(r.x - currentX, 2) + Math.pow(r.y - currentY, 2));
                // Calculate a score based on distance and value
                // Prioritize high value and short distance
                const score = r.value / (distance + 1);
                return { ...r, distance, score };
            });
            
            // Sort by score (descending)
            resourcesWithDistance.sort((a, b) => b.score - a.score);
            
            // Get the highest scoring resource
            const nextResource = resourcesWithDistance[0];
            
            // Add to the path
            miningPath.push(nextResource);
            
            // Update current position
            currentX = nextResource.x;
            currentY = nextResource.y;
            
            // Remove this resource from available list
            const index = availableResources.indexOf(nextResource);
            availableResources.splice(index, 1);
        }
        
        // Draw the path lines
        drawPathLines();
        
        return miningPath;
    }
    
    // Draw lines showing the mining path
    function drawPathLines() {
        // Remove existing path lines
        pathLines.forEach(line => line.remove());
        pathLines = [];
        
        if (miningPath.length === 0) {
            return;
        }
        
        // Start from the miner's position
        let lastX = miner.x;
        let lastY = miner.y;
        
        // Draw a line to each resource in the path
        miningPath.forEach(resource => {
            const line = document.createElement('div');
            line.className = 'path-line';
            
            // Position at start point
            line.style.left = `${lastX}px`;
            line.style.top = `${lastY}px`;
            
            // Calculate length and angle
            const dx = resource.x - lastX;
            const dy = resource.y - lastY;
            const length = Math.sqrt(dx * dx + dy * dy);
            const angle = Math.atan2(dy, dx) * 180 / Math.PI;
            
            // Set dimensions and rotation
            line.style.width = `${length}px`;
            line.style.transform = `rotate(${angle}deg)`;
            
            // Add to the DOM
            miningGrid.appendChild(line);
            pathLines.push(line);
            
            // Update last point
            lastX = resource.x;
            lastY = resource.y;
        });
    }
    
    // Filter resources by type
    function filterResources(type) {
        document.querySelectorAll('.resource-node').forEach(node => {
            if (type === 'all' || node.classList.contains(`resource-${type}`)) {
                node.style.opacity = '1';
            } else {
                node.style.opacity = '0.3';
            }
        });
    }
    
    // Toggle 3D view
    function toggle3DView(e) {
        if (e.target.checked) {
            miningGrid.style.perspective = '1000px';
            miningGrid.style.transform = 'rotateX(15deg)';
        } else {
            miningGrid.style.perspective = 'none';
            miningGrid.style.transform = 'none';
        }
    }
    
    // Toggle path lines visibility
    function togglePathLines(e) {
        document.querySelectorAll('.path-line').forEach(line => {
            line.style.display = e.target.checked ? 'block' : 'none';
        });
    }
    
    // Show target indicator at the next resource
    function showTargetIndicator() {
        // Remove existing indicator
        if (targetIndicator) {
            targetIndicator.remove();
        }
        
        if (currentPathIndex >= miningPath.length) {
            return;
        }
        
        // Create new indicator
        const target = miningPath[currentPathIndex];
        targetIndicator = document.createElement('div');
        targetIndicator.className = 'target-indicator';
        targetIndicator.style.left = `${target.x}px`;
        targetIndicator.style.top = `${target.y}px`;
        
        miningGrid.appendChild(targetIndicator);
    }
    
    // Start the mining simulation
    function startSimulation() {
        if (simulationRunning) return;
        
        // Toggle button states
        document.getElementById('startSimulation').disabled = true;
        document.getElementById('pauseSimulation').disabled = false;
        
        simulationRunning = true;
        startTime = Date.now();
        
        // Start the animation loop
        animateSimulation();
    }
    
    // Pause the mining simulation
    function pauseSimulation() {
        simulationRunning = false;
        
        // Toggle button states
        document.getElementById('startSimulation').disabled = false;
        document.getElementById('pauseSimulation').disabled = true;
        
        // Cancel animation
        if (animationFrame) {
            cancelAnimationFrame(animationFrame);
        }
        
        // Stop mining animation if active
        if (miner.mining) {
            miner.mining = false;
            miner.element.classList.remove('mining-animation');
        }
    }
    
    // Reset the mining simulation
    function resetSimulation() {
        // Stop simulation if running
        if (simulationRunning) {
            pauseSimulation();
        }
        
        // Reset counters
        currentPathIndex = 0;
        
        // Reset stats
        resourceStats = {
            totalMined: 0,
            ores: { total: 0, common: 0, rare: 0, value: 0 },
            gems: { total: 0, common: 0, rare: 0, value: 0 },
            chests: { total: 0, common: 0, rare: 0, value: 0 },
            special: { total: 0, value: 0 },
            distance: 0,
            miningRate: 0,
            efficiency: 0,
            timeline: []
        };
        
        // Reset timeline chart
        timelineChart.data.labels = [];
        timelineChart.data.datasets.forEach(dataset => {
            dataset.data = [];
        });
        timelineChart.update();
        
        // Reset UI
        document.getElementById('startSimulation').disabled = false;
        document.getElementById('pauseSimulation').disabled = true;
        
        // Clear existing resources and regenerate
        generateResources();
        
        // Reset miner position
        createMiner();
        
        // Recalculate path
        calculateMiningPath();
        
        // Show target indicator
        showTargetIndicator();
        
        // Update stats display
        updateStats();
        
        // Render minimap
        renderMinimap();
    }
    
    // Main animation loop for the simulation
    function animateSimulation() {
        if (!simulationRunning) return;
        
        if (currentPathIndex >= miningPath.length) {
            // Reached the end of the path
            pauseSimulation();
            return;
        }
        
        const targetResource = miningPath[currentPathIndex];
        
        // Calculate distance to target
        const dx = targetResource.x - miner.x;
        const dy = targetResource.y - miner.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 5) {
            // We've reached the resource - mine it
            if (!miner.mining) {
                miner.mining = true;
                miner.element.classList.add('mining-animation');
                
                // Simulate mining time based on resource type
                let miningTime;
                switch(targetResource.type) {
                    case 'ore': miningTime = 1000; break;
                    case 'gem': miningTime = 1500; break;
                    case 'chest': miningTime = 2000; break;
                    case 'special': miningTime = 2500; break;
                    default: miningTime = 1000;
                }
                
                // Adjust for simulation speed
                miningTime = miningTime / simulationSpeed;
                
                // After mining time, collect the resource
                setTimeout(() => {
                    if (!simulationRunning) return; // Check if still running
                    
                    // Mark as mined
                    collectResource(targetResource);
                    
                    // Move to next target
                    currentPathIndex++;
                    
                    // Update target indicator
                    showTargetIndicator();
                    
                    // Stop mining animation
                    miner.mining = false;
                    miner.element.classList.remove('mining-animation');
                }, miningTime);
            }
        } else {
            // Move toward the resource
            const moveSpeed = 2 * simulationSpeed;
            const moveRatio = moveSpeed / distance;
            
            miner.x += dx * moveRatio;
            miner.y += dy * moveRatio;
            
            miner.element.style.left = `${miner.x}px`;
            miner.element.style.top = `${miner.y}px`;
            
            // Update stats
            resourceStats.distance += moveSpeed;
            
            // Update minimap view
            updateMinimapViewBox();
        }
        
        // Continue animation loop
        animationFrame = requestAnimationFrame(animateSimulation);
    }
    
    // Collect a resource and update stats
    function collectResource(resource) {
        // Mark as mined in the resource data
        resource.mined = true;
        
        // Add collection animation
        resource.element.classList.add('collected');
        
        // Update stats based on resource type
        resourceStats.totalMined++;
        
        switch(resource.type) {
            case 'ore':
                resourceStats.ores.total++;
                if (resource.rare) {
                    resourceStats.ores.rare++;
                    resourceStats.ores.value += resourceValues.ore.rare;
                } else {
                    resourceStats.ores.common++;
                    resourceStats.ores.value += resourceValues.ore.common;
                }
                break;
                
            case 'gem':
                resourceStats.gems.total++;
                if (resource.rare) {
                    resourceStats.gems.rare++;
                    resourceStats.gems.value += resourceValues.gem.rare;
                } else {
                    resourceStats.gems.common++;
                    resourceStats.gems.value += resourceValues.gem.common;
                }
                break;
                
            case 'chest':
                resourceStats.chests.total++;
                if (resource.rare) {
                    resourceStats.chests.rare++;
                    resourceStats.chests.value += resourceValues.chest.rare;
                } else {
                    resourceStats.chests.common++;
                    resourceStats.chests.value += resourceValues.chest.common;
                }
                break;
                
            case 'special':
                resourceStats.special.total++;
                resourceStats.special.value += resourceValues.special.value;
                break;
        }
        
        // Calculate mining rate
        const elapsedMinutes = (Date.now() - startTime) / 60000;
        resourceStats.miningRate = resourceStats.totalMined / Math.max(0.1, elapsedMinutes);
        
        // Calculate efficiency (value per distance)
        const totalValue = resourceStats.ores.value + resourceStats.gems.value + 
                          resourceStats.chests.value + resourceStats.special.value;
        resourceStats.efficiency = totalValue / Math.max(1, resourceStats.distance) * 100;
        
        // Update timeline
        updateTimeline();
        
        // Update UI
        updateStats();
        updateResourceProgress();
        
        // Remove the resource element after animation
        setTimeout(() => {
            resource.element.remove();
        }, 500);
    }
    
    // Update the timeline chart with current data
    function updateTimeline() {
        const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
        
        // Add new data point
        timelineChart.data.labels.push(elapsedSeconds + 's');
        
        // Limit to last 60 seconds
        if (timelineChart.data.labels.length > 60) {
            timelineChart.data.labels.shift();
            timelineChart.data.datasets.forEach(dataset => {
                dataset.data.shift();
            });
        }
        
        // Update datasets
        timelineChart.data.datasets[0].data.push(resourceStats.ores.total);
        timelineChart.data.datasets[1].data.push(resourceStats.gems.total);
        timelineChart.data.datasets[2].data.push(resourceStats.chests.total);
        timelineChart.data.datasets[3].data.push(resourceStats.special.total);
        
        // Update chart
        timelineChart.update();
    }
    
    // Update the stats display
    function updateStats() {
        // Mining stats
        document.getElementById('statsTotalMined').textContent = resourceStats.totalMined;
        document.getElementById('statsMiningRate').textContent = resourceStats.miningRate.toFixed(1) + '/min';
        document.getElementById('statsDistance').textContent = resourceStats.distance.toFixed(0) + ' units';
        document.getElementById('statsEfficiency').textContent = resourceStats.efficiency.toFixed(1);
        
        // Ore stats
        document.getElementById('statsOresMined').textContent = resourceStats.ores.total;
        document.getElementById('statsOresCommon').textContent = resourceStats.ores.common;
        document.getElementById('statsOresRare').textContent = resourceStats.ores.rare;
        document.getElementById('statsOresValue').textContent = resourceStats.ores.value;
        
        // Gem stats
        document.getElementById('statsGemsMined').textContent = resourceStats.gems.total;
        document.getElementById('statsGemsCommon').textContent = resourceStats.gems.common;
        document.getElementById('statsGemsRare').textContent = resourceStats.gems.rare;
        document.getElementById('statsGemsValue').textContent = resourceStats.gems.value;
        
        // Chest stats
        document.getElementById('statsChestsMined').textContent = resourceStats.chests.total;
        document.getElementById('statsChestsCommon').textContent = resourceStats.chests.common;
        document.getElementById('statsChestsRare').textContent = resourceStats.chests.rare;
        document.getElementById('statsChestsValue').textContent = resourceStats.chests.value;
    }
    
    // Update the resource progress bars
    function updateResourceProgress() {
        // Count remaining resources by type
        const remainingResources = resources.filter(r => !r.mined);
        const remainingByType = {
            ore: remainingResources.filter(r => r.type === 'ore').length,
            gem: remainingResources.filter(r => r.type === 'gem').length,
            chest: remainingResources.filter(r => r.type === 'chest').length,
            special: remainingResources.filter(r => r.type === 'special').length
        };
        
        // Update progress text
        document.getElementById('remainingResources').textContent = remainingResources.length;
        
        // Calculate total for percentages
        const total = remainingResources.length;
        if (total === 0) return;
        
        // Update progress bars
        document.getElementById('progressOre').style.width = `${(remainingByType.ore / total) * 100}%`;
        document.getElementById('progressOre').textContent = `Ores: ${remainingByType.ore}`;
        
        document.getElementById('progressGem').style.width = `${(remainingByType.gem / total) * 100}%`;
        document.getElementById('progressGem').textContent = `Gems: ${remainingByType.gem}`;
        
        document.getElementById('progressChest').style.width = `${(remainingByType.chest / total) * 100}%`;
        document.getElementById('progressChest').textContent = `Chests: ${remainingByType.chest}`;
        
        document.getElementById('progressSpecial').style.width = `${(remainingByType.special / total) * 100}%`;
        document.getElementById('progressSpecial').textContent = `Special: ${remainingByType.special}`;
    }
    
    // Render the minimap
    function renderMinimap() {
        // Clear existing minimap elements (except the view box)
        document.querySelectorAll('.minimap-resource, .minimap-player').forEach(el => el.remove());
        
        // Add resources to minimap
        resources.forEach(resource => {
            addResourceToMinimap(resource.x, resource.y, resource.type);
        });
        
        // Add miner to minimap
        addMinerToMinimap();
        
        // Update view box
        updateMinimapViewBox();
    }
    
    // Initialize the visualizer on page load
    initializeVisualizer();
});