"""
PS99 Comprehensive Database

This module contains structured data about Pet Simulator 99 game elements
to support the luck enhancer executor and other automation tools.
"""

# API Endpoints
API_ENDPOINTS = {
    "base_url": "https://api.biggames.io",
    "documentation": "https://docs.biggamesapi.io/",
    "player_info": "/v1/player/info",
    "inventory": "/v1/ps99/inventory",
    "eggs": "/v1/ps99/eggs",
    "boosts_inventory": "/v1/ps99/inventory/boosts",
    "activate_boost": "/v1/ps99/boosts/activate",
    "hatch_log": "/v1/ps99/hatchlog",
    "server_players": "/v1/server/players",
    "server_info": "/v1/server/info",
    "open_egg": "/v1/ps99/eggs/open"
}

# Pet Variants
PET_VARIANTS = {
    "normal": {"multiplier": 1.0, "detection_colors": [(255, 255, 255), (200, 200, 200)]},
    "rainbow": {"multiplier": 1.5, "detection_colors": [(255, 0, 255), (255, 100, 255)]},
    "shiny": {"multiplier": 2.0, "detection_colors": [(255, 215, 0), (255, 255, 0)]},
    "huge": {"multiplier": 5.0, "detection_colors": [(0, 255, 255), (100, 255, 255)]},
    "titanic": {"multiplier": 10.0, "detection_colors": [(255, 0, 0), (255, 100, 100)]},
    "gargantuan": {"multiplier": 15.0, "detection_colors": [(180, 0, 255), (200, 100, 255)]}
}

# Boosts and their effects
BOOSTS = {
    "luck": {
        "multiplier": 2.0,
        "duration": 1800,  # 30 minutes in seconds
        "detection_colors": [(0, 255, 0), (100, 255, 100)],
        "ui_element": "LuckBoostIcon",
        "key_binding": "1"
    },
    "super_luck": {
        "multiplier": 3.0,
        "duration": 1800,
        "detection_colors": [(0, 255, 0), (0, 200, 0)],
        "ui_element": "SuperLuckBoostIcon",
        "key_binding": "2"
    },
    "triple_hatch": {
        "multiplier": 1.0,  # No luck effect, just hatches 3 eggs
        "duration": 1800,
        "detection_colors": [(255, 255, 0), (200, 200, 0)],
        "ui_element": "TripleHatchIcon",
        "key_binding": "3"
    },
    "ultra_lucky": {
        "multiplier": 4.0,
        "duration": 1800,
        "detection_colors": [(255, 128, 0), (255, 150, 50)],
        "ui_element": "UltraLuckyIcon",
        "key_binding": "4"
    }
}

# Egg types and their base chances
EGG_TYPES = {
    "Basic Egg": {
        "id": "basic_egg",
        "price": 750,
        "currency": "coins",
        "world": "Spawn World",
        "type": "regular",
        "base_chances": {
            "huge": 0.005,
            "titanic": 0.001,
            "gargantuan": 0.0005,
            "rainbow": 0.1,
            "shiny": 0.05
        },
        "detection_colors": [(255, 255, 255), (240, 240, 240)],
        "location": {"x": 150, "y": 200, "z": 50}
    },
    "Spotted Egg": {
        "id": "spotted_egg",
        "price": 2500,
        "currency": "coins",
        "world": "Spawn World",
        "type": "regular",
        "base_chances": {
            "huge": 0.007,
            "titanic": 0.0015,
            "gargantuan": 0.0007,
            "rainbow": 0.12,
            "shiny": 0.06
        },
        "detection_colors": [(255, 255, 200), (240, 240, 190)],
        "location": {"x": 160, "y": 200, "z": 50}
    },
    "Doodle Egg": {
        "id": "doodle_egg",
        "price": 50000,
        "currency": "gems",
        "world": "Doodle World",
        "type": "regular",
        "base_chances": {
            "huge": 0.01,
            "titanic": 0.002,
            "gargantuan": 0.001,
            "rainbow": 0.15,
            "shiny": 0.08
        },
        "detection_colors": [(200, 255, 200), (180, 240, 180)],
        "location": {"x": 500, "y": 200, "z": -150}
    },
    "Cat Egg": {
        "id": "cat_egg",
        "price": 10000,
        "currency": "coins",
        "world": "Cat World",
        "type": "regular",
        "base_chances": {
            "huge": 0.008,
            "titanic": 0.0016,
            "gargantuan": 0.0008,
            "rainbow": 0.13,
            "shiny": 0.065
        },
        "detection_colors": [(255, 200, 200), (240, 190, 190)],
        "location": {"x": 350, "y": 200, "z": 100}
    },
    "Dog Egg": {
        "id": "dog_egg",
        "price": 25000,
        "currency": "coins",
        "world": "Dog World",
        "type": "regular",
        "base_chances": {
            "huge": 0.009,
            "titanic": 0.0018,
            "gargantuan": 0.0009,
            "rainbow": 0.14,
            "shiny": 0.07
        },
        "detection_colors": [(200, 200, 255), (190, 190, 240)],
        "location": {"x": 400, "y": 200, "z": 150}
    },
    "Pixel Egg": {
        "id": "pixel_egg",
        "price": 100000,
        "currency": "gems",
        "world": "Pixel World",
        "type": "regular",
        "base_chances": {
            "huge": 0.015,
            "titanic": 0.003,
            "gargantuan": 0.0015,
            "rainbow": 0.2,
            "shiny": 0.1
        },
        "detection_colors": [(255, 128, 255), (240, 120, 240)],
        "location": {"x": 600, "y": 200, "z": -200}
    },
    "Axolotl Egg": {
        "id": "axolotl_egg",
        "price": 200000,
        "currency": "gems",
        "world": "Axolotl World",
        "type": "regular",
        "base_chances": {
            "huge": 0.02,
            "titanic": 0.004,
            "gargantuan": 0.002,
            "rainbow": 0.25,
            "shiny": 0.125
        },
        "detection_colors": [(180, 255, 255), (170, 240, 240)],
        "location": {"x": 700, "y": 200, "z": -250}
    },
    "Kawaii Egg": {
        "id": "kawaii_egg",
        "price": 500000,
        "currency": "gems",
        "world": "Kawaii World",
        "type": "regular",
        "base_chances": {
            "huge": 0.025,
            "titanic": 0.005,
            "gargantuan": 0.0025,
            "rainbow": 0.3,
            "shiny": 0.15
        },
        "detection_colors": [(255, 200, 255), (240, 190, 240)],
        "location": {"x": 800, "y": 200, "z": -300}
    },
    # End World Eggs
    "Void Egg": {
        "id": "void_egg",
        "price": 1000000,
        "currency": "gems",
        "world": "End World",
        "type": "end_world",
        "base_chances": {
            "huge": 0.03,
            "titanic": 0.01,
            "gargantuan": 0.005,
            "rainbow": 0.35,
            "shiny": 0.2
        },
        "detection_colors": [(50, 0, 100), (40, 0, 80)],
        "location": {"x": 1200, "y": 300, "z": -500}
    },
    "Galaxy Egg": {
        "id": "galaxy_egg",
        "price": 2000000,
        "currency": "gems",
        "world": "End World",
        "type": "end_world",
        "base_chances": {
            "huge": 0.035,
            "titanic": 0.012,
            "gargantuan": 0.006,
            "rainbow": 0.4,
            "shiny": 0.25
        },
        "detection_colors": [(20, 0, 150), (10, 0, 120)],
        "location": {"x": 1300, "y": 300, "z": -550}
    },
    # Exclusive Eggs
    "Diamond Egg": {
        "id": "diamond_egg",
        "price": 5000000,
        "currency": "gems",
        "world": "VIP Area",
        "type": "exclusive",
        "base_chances": {
            "huge": 0.05,
            "titanic": 0.015,
            "gargantuan": 0.008,
            "rainbow": 0.5,
            "shiny": 0.3
        },
        "detection_colors": [(0, 220, 255), (0, 200, 230)],
        "location": {"x": 1500, "y": 400, "z": -700}
    },
    "Golden Egg": {
        "id": "golden_egg",
        "price": 10000000,
        "currency": "gems",
        "world": "VIP Area",
        "type": "exclusive",
        "base_chances": {
            "huge": 0.06,
            "titanic": 0.02,
            "gargantuan": 0.01,
            "rainbow": 0.6,
            "shiny": 0.4
        },
        "detection_colors": [(255, 215, 0), (235, 195, 0)],
        "location": {"x": 1550, "y": 400, "z": -750}
    },
    "Rainbow Egg": {
        "id": "rainbow_egg",
        "price": 20000000,
        "currency": "gems",
        "world": "VIP Area",
        "type": "exclusive",
        "base_chances": {
            "huge": 0.075,
            "titanic": 0.025,
            "gargantuan": 0.0125,
            "rainbow": 1.0,  # Guaranteed rainbow
            "shiny": 0.5
        },
        "detection_colors": [(255, 0, 255), (235, 0, 235)],
        "location": {"x": 1600, "y": 400, "z": -800}
    },
    # Presents and Gift Bags
    "Small Present": {
        "id": "small_present",
        "price": 100000,
        "currency": "gems",
        "world": "Event Area",
        "type": "present",
        "base_chances": {
            "huge": 0.02,
            "titanic": 0.005,
            "gargantuan": 0.0025,
            "rainbow": 0.2,
            "shiny": 0.1
        },
        "detection_colors": [(255, 50, 50), (235, 40, 40)],
        "location": {"x": 900, "y": 200, "z": -400}
    },
    "Large Present": {
        "id": "large_present",
        "price": 500000,
        "currency": "gems",
        "world": "Event Area",
        "type": "present",
        "base_chances": {
            "huge": 0.04,
            "titanic": 0.01,
            "gargantuan": 0.005,
            "rainbow": 0.3,
            "shiny": 0.15
        },
        "detection_colors": [(50, 255, 50), (40, 235, 40)],
        "location": {"x": 950, "y": 200, "z": -450}
    },
    "Gift Bag": {
        "id": "gift_bag",
        "price": 1000000,
        "currency": "gems",
        "world": "Event Area",
        "type": "gift",
        "base_chances": {
            "huge": 0.05,
            "titanic": 0.015,
            "gargantuan": 0.0075,
            "rainbow": 0.4,
            "shiny": 0.2
        },
        "detection_colors": [(50, 50, 255), (40, 40, 235)],
        "location": {"x": 1000, "y": 200, "z": -500}
    },
    "Premium Gift Bag": {
        "id": "premium_gift_bag",
        "price": 2000000,
        "currency": "gems",
        "world": "VIP Area",
        "type": "gift",
        "base_chances": {
            "huge": 0.08,
            "titanic": 0.025,
            "gargantuan": 0.015,
            "rainbow": 0.6,
            "shiny": 0.4
        },
        "detection_colors": [(255, 215, 0), (235, 195, 0)],
        "location": {"x": 1650, "y": 400, "z": -850}
    }
}

# Worlds and their characteristics
WORLDS = {
    "Spawn World": {
        "id": "spawn_world",
        "teleport_shortcut": "Home",
        "eggs": ["Basic Egg", "Spotted Egg"],
        "mining_areas": ["Basic Mines", "Treasure Cave"],
        "npcs": ["Tutorial Guide", "Merchant"],
        "detection_colors": [(120, 200, 80), (100, 180, 70)]
    },
    "Cat World": {
        "id": "cat_world",
        "teleport_shortcut": "Cat",
        "eggs": ["Cat Egg"],
        "mining_areas": ["Kitty Mines", "Diamond Paws"],
        "npcs": ["Cat Trainer", "Meowchant"],
        "detection_colors": [(255, 180, 180), (240, 160, 160)]
    },
    "Dog World": {
        "id": "dog_world",
        "teleport_shortcut": "Dog",
        "eggs": ["Dog Egg"],
        "mining_areas": ["Doggy Dig", "Bone Yard"],
        "npcs": ["Dog Trainer", "Bone Collector"],
        "detection_colors": [(180, 180, 255), (160, 160, 240)]
    },
    "Doodle World": {
        "id": "doodle_world",
        "teleport_shortcut": "Doodle",
        "eggs": ["Doodle Egg"],
        "mining_areas": ["Sketch Mines", "Canvas Cavern"],
        "npcs": ["Artist", "Doodle Dealer"],
        "detection_colors": [(180, 255, 180), (160, 240, 160)]
    },
    "Pixel World": {
        "id": "pixel_world",
        "teleport_shortcut": "Pixel",
        "eggs": ["Pixel Egg"],
        "mining_areas": ["Bit Mines", "8-Bit Depths"],
        "npcs": ["Game Dev", "Pixel Merchant"],
        "detection_colors": [(255, 128, 255), (240, 110, 240)]
    },
    "Axolotl World": {
        "id": "axolotl_world",
        "teleport_shortcut": "Axolotl",
        "eggs": ["Axolotl Egg"],
        "mining_areas": ["Aquatic Mines", "Deep Blue"],
        "npcs": ["Marine Biologist", "Gill"],
        "detection_colors": [(150, 255, 255), (130, 240, 240)]
    },
    "Kawaii World": {
        "id": "kawaii_world",
        "teleport_shortcut": "Kawaii",
        "eggs": ["Kawaii Egg"],
        "mining_areas": ["Cute Caverns", "Adorable Abyss"],
        "npcs": ["Kawaii Guide", "Cutie Collector"],
        "detection_colors": [(255, 180, 255), (240, 160, 240)]
    },
    "Trading Plaza": {
        "id": "trading_plaza",
        "teleport_shortcut": "Trade",
        "eggs": [],
        "mining_areas": [],
        "npcs": ["Trade Manager", "Value Checker"],
        "detection_colors": [(240, 240, 240), (220, 220, 220)]
    },
    "Trading Plaza Pro": {
        "id": "trading_plaza_pro",
        "teleport_shortcut": "TradePro",
        "eggs": [],
        "mining_areas": [],
        "npcs": ["Pro Trader", "Marketplace Owner"],
        "detection_colors": [(255, 215, 0), (240, 200, 0)]
    }
}

# Mining resources and their characteristics
MINING_RESOURCES = {
    "Stone": {
        "id": "stone",
        "value": 1,
        "health": 5,
        "detection_colors": [(128, 128, 128), (100, 100, 100)],
        "respawn_time": 3
    },
    "Coal": {
        "id": "coal",
        "value": 2,
        "health": 8,
        "detection_colors": [(40, 40, 40), (30, 30, 30)],
        "respawn_time": 5
    },
    "Iron": {
        "id": "iron",
        "value": 5,
        "health": 12,
        "detection_colors": [(200, 200, 200), (180, 180, 180)],
        "respawn_time": 8
    },
    "Gold": {
        "id": "gold",
        "value": 10,
        "health": 15,
        "detection_colors": [(255, 215, 0), (240, 200, 0)],
        "respawn_time": 10
    },
    "Diamond": {
        "id": "diamond",
        "value": 25,
        "health": 20,
        "detection_colors": [(0, 200, 255), (0, 180, 240)],
        "respawn_time": 15
    },
    "Emerald": {
        "id": "emerald",
        "value": 50,
        "health": 25,
        "detection_colors": [(0, 255, 128), (0, 240, 120)],
        "respawn_time": 20
    },
    "Ruby": {
        "id": "ruby",
        "value": 100,
        "health": 30,
        "detection_colors": [(255, 0, 0), (240, 0, 0)],
        "respawn_time": 25
    },
    "Treasure Chest": {
        "id": "treasure_chest",
        "value": 250,
        "health": 50,
        "detection_colors": [(153, 101, 21), (140, 90, 20)],
        "respawn_time": 30
    },
    "Super Chest": {
        "id": "super_chest",
        "value": 500,
        "health": 100,
        "detection_colors": [(218, 165, 32), (200, 150, 30)],
        "respawn_time": 60
    },
    "Mega Chest": {
        "id": "mega_chest",
        "value": 1000,
        "health": 200,
        "detection_colors": [(255, 215, 0), (240, 200, 0)],
        "respawn_time": 120
    }
}

# Enchantments that can be applied to tools
ENCHANTMENTS = {
    "Power": {
        "id": "power",
        "max_level": 5,
        "effect": "Increases mining damage",
        "detection_colors": [(255, 0, 0), (240, 0, 0)],
        "key_binding": "F1"
    },
    "Speed": {
        "id": "speed",
        "max_level": 5,
        "effect": "Increases mining speed",
        "detection_colors": [(0, 255, 0), (0, 240, 0)],
        "key_binding": "F2"
    },
    "Fortune": {
        "id": "fortune",
        "max_level": 5,
        "effect": "Increases resource drops",
        "detection_colors": [(255, 255, 0), (240, 240, 0)],
        "key_binding": "F3"
    },
    "Luck": {
        "id": "luck",
        "max_level": 5,
        "effect": "Increases rare resource chance",
        "detection_colors": [(0, 255, 255), (0, 240, 240)],
        "key_binding": "F4"
    },
    "PowerBall": {
        "id": "powerball",
        "max_level": 5,
        "effect": "Chance to instantly mine resources",
        "detection_colors": [(255, 0, 255), (240, 0, 240)],
        "key_binding": "F5"
    },
    "Replenish": {
        "id": "replenish",
        "max_level": 5,
        "effect": "Resource respawn faster nearby",
        "detection_colors": [(0, 128, 255), (0, 120, 240)],
        "key_binding": "F6"
    }
}

# Game events that affect mining and hatching
EVENTS = {
    "Lucky Hour": {
        "id": "lucky_hour",
        "effect": "Increased luck for all eggs",
        "multiplier": 2.0,
        "detection_text": "LUCKY HOUR!",
        "detection_colors": [(255, 255, 0), (240, 240, 0)]
    },
    "Mining Frenzy": {
        "id": "mining_frenzy",
        "effect": "Increased mining speed for all resources",
        "multiplier": 2.0,
        "detection_text": "MINING FRENZY!",
        "detection_colors": [(0, 255, 0), (0, 240, 0)]
    },
    "Gem Rush": {
        "id": "gem_rush",
        "effect": "Increased gem drops from mining",
        "multiplier": 3.0,
        "detection_text": "GEM RUSH!",
        "detection_colors": [(255, 0, 255), (240, 0, 240)]
    },
    "Triple Eggs": {
        "id": "triple_eggs",
        "effect": "Hatch 3 eggs at once",
        "multiplier": 1.0,
        "detection_text": "TRIPLE EGGS!",
        "detection_colors": [(0, 255, 255), (0, 240, 240)]
    }
}

# UI Element detection for the luck enhancer
UI_ELEMENTS = {
    "Egg_Menu": {
        "position": {"x1": 150, "y1": 400, "x2": 250, "y2": 600},
        "detection_colors": [(240, 240, 240), (230, 230, 230)],
        "detection_text": "EGGS"
    },
    "Open_Egg_Button": {
        "position": {"x1": 400, "y1": 500, "x2": 500, "y2": 540},
        "detection_colors": [(0, 200, 0), (0, 180, 0)],
        "detection_text": "OPEN"
    },
    "Boost_Active_Indicator": {
        "position": {"x1": 50, "y1": 100, "x2": 150, "y2": 150},
        "detection_colors": [(0, 255, 0), (0, 240, 0)],
        "detection_text": "BOOST ACTIVE"
    },
    "Luck_Boost_Button": {
        "position": {"x1": 300, "y1": 400, "x2": 350, "y2": 450},
        "detection_colors": [(0, 255, 0), (0, 240, 0)],
        "detection_text": "LUCK"
    },
    "Super_Luck_Boost_Button": {
        "position": {"x1": 360, "y1": 400, "x2": 410, "y2": 450},
        "detection_colors": [(0, 200, 0), (0, 180, 0)],
        "detection_text": "SUPER"
    },
    "Hatch_Result_Notification": {
        "position": {"x1": 300, "y1": 200, "x2": 500, "y2": 300},
        "detection_colors": [(255, 255, 255), (240, 240, 240)],
        "detection_text": "You hatched"
    }
}

# Optimal luck enhancement timings
LUCK_ENHANCEMENT_TIMINGS = {
    "optimal_seconds": [3, 8, 15, 27, 42],  # Seconds after the minute that have higher luck
    "optimal_milliseconds": [50, 150, 250, 450, 850],  # Milliseconds that have higher luck
    "click_patterns": [
        [0.1, 0.3, 0.1],  # Short, long, short pause pattern
        [0.2, 0.1, 0.2],  # Medium, short, medium pause pattern
        [0.15, 0.25, 0.15]  # Mixed pause pattern
    ],
    "wait_durations": {
        "before_open": 0.5,
        "after_open": 1.5,
        "between_eggs": 0.8
    }
}

# Detection avoidance techniques
DETECTION_AVOIDANCE = {
    "input_randomization": {
        "mouse_movement_jitter": 5,  # pixels
        "click_duration_variation": 0.1,  # seconds
        "key_press_duration_variation": 0.05  # seconds
    },
    "timing_randomization": {
        "action_delay_min": 0.3,  # seconds
        "action_delay_max": 1.2,  # seconds
        "pattern_break_frequency": 7  # actions
    },
    "behavior_patterns": {
        "occasional_camera_movement": True,
        "random_jump_frequency": 15,  # actions
        "character_movement_pause": 10  # seconds
    },
    "script_detection_countermeasures": {
        "variable_naming_obfuscation": True,
        "execution_path_randomization": True,
        "memory_usage_optimization": True,
        "process_name_masking": True
    }
}

# API authentication requirements
API_AUTHENTICATION = {
    "auth_key_header": "Authorization",
    "auth_key_prefix": "Bearer",
    "user_id_header": "X-User-ID",
    "session_expiry": 86400,  # 24 hours in seconds
    "request_id_header": "X-Request-ID"
}

# Potions for luck enhancement
POTIONS = {
    "Luck Potion": {
        "id": "luck_potion",
        "durability": 300,  # seconds
        "effect": "Increases hatch luck",
        "multiplier": 1.5,
        "detection_colors": [(0, 255, 0), (0, 240, 0)],
        "usage_key": "P"
    },
    "Super Luck Potion": {
        "id": "super_luck_potion",
        "durability": 600,  # seconds
        "effect": "Greatly increases hatch luck",
        "multiplier": 3.0,
        "detection_colors": [(0, 0, 255), (0, 0, 240)],
        "usage_key": "O"
    },
    "Triple Hatch Potion": {
        "id": "triple_hatch_potion",
        "durability": 1800,  # seconds
        "effect": "Triple egg hatching",
        "multiplier": 1.0,
        "detection_colors": [(255, 0, 255), (240, 0, 240)],
        "usage_key": "T"
    },
    "Enchant Potion": {
        "id": "enchant_potion",
        "durability": 1800,  # seconds
        "effect": "Increases enchant luck",
        "multiplier": 2.0,
        "detection_colors": [(255, 255, 0), (240, 240, 0)],
        "usage_key": "E"
    }
}

# Glitch drives for additional bonuses
GLITCH_DRIVES = {
    "Basic Glitch Drive": {
        "id": "basic_glitch_drive",
        "effect": "Basic glitch enhancement",
        "multiplier": 1.25,
        "detection_colors": [(128, 0, 255), (110, 0, 240)],
        "usage_key": "G1"
    },
    "Advanced Glitch Drive": {
        "id": "advanced_glitch_drive",
        "effect": "Advanced glitch enhancement",
        "multiplier": 2.5,
        "detection_colors": [(200, 0, 255), (180, 0, 240)],
        "usage_key": "G2"
    },
    "Ultimate Glitch Drive": {
        "id": "ultimate_glitch_drive",
        "effect": "Ultimate glitch enhancement",
        "multiplier": 5.0,
        "detection_colors": [(255, 0, 255), (240, 0, 240)],
        "usage_key": "G3"
    }
}

# Enchant items for boosting enchantments
ENCHANT_ITEMS = {
    "Enchant Dust": {
        "id": "enchant_dust",
        "effect": "Minor enchant enhancement",
        "multiplier": 1.1,
        "detection_colors": [(200, 200, 200), (180, 180, 180)],
        "usage_key": "D"
    },
    "Enchant Crystal": {
        "id": "enchant_crystal",
        "effect": "Medium enchant enhancement",
        "multiplier": 1.5,
        "detection_colors": [(0, 200, 255), (0, 180, 240)],
        "usage_key": "C"
    },
    "Enchant Orb": {
        "id": "enchant_orb",
        "effect": "Major enchant enhancement",
        "multiplier": 2.0,
        "detection_colors": [(255, 100, 0), (240, 80, 0)],
        "usage_key": "B"
    }
}

# Luck books for special luck enhancement
LUCK_BOOKS = {
    "Luck Book I": {
        "id": "luck_book_1",
        "effect": "Basic luck enhancement for rare pets",
        "multiplier": 1.5,
        "detection_colors": [(255, 215, 0), (240, 200, 0)],
        "usage_key": "L1"
    },
    "Luck Book II": {
        "id": "luck_book_2",
        "effect": "Advanced luck enhancement for rare pets",
        "multiplier": 2.5,
        "detection_colors": [(255, 230, 0), (240, 215, 0)],
        "usage_key": "L2"
    },
    "Luck Book III": {
        "id": "luck_book_3",
        "effect": "Ultimate luck enhancement for rare pets",
        "multiplier": 4.0,
        "detection_colors": [(255, 245, 0), (240, 230, 0)],
        "usage_key": "L3"
    }
}

# Huge hunter items for improved huge pet chances
HUGE_HUNTER_ITEMS = {
    "Huge Hunter Charm": {
        "id": "huge_hunter_charm",
        "effect": "Increases chance of hatching Huge pets",
        "multiplier": 2.0,
        "detection_colors": [(0, 255, 255), (0, 240, 240)],
        "usage_key": "H1"
    },
    "Huge Hunter Amulet": {
        "id": "huge_hunter_amulet",
        "effect": "Greatly increases chance of hatching Huge pets",
        "multiplier": 4.0,
        "detection_colors": [(0, 200, 255), (0, 180, 240)],
        "usage_key": "H2"
    },
    "Huge Hunter Talisman": {
        "id": "huge_hunter_talisman",
        "effect": "Massively increases chance of hatching Huge pets",
        "multiplier": 8.0,
        "detection_colors": [(0, 150, 255), (0, 130, 240)],
        "usage_key": "H3"
    }
}

# Special event items for event-specific bonuses
SPECIAL_EVENT_ITEMS = {
    "Event Pass": {
        "id": "event_pass",
        "effect": "Unlocks special event areas",
        "multiplier": 1.0,
        "detection_colors": [(255, 0, 0), (240, 0, 0)],
        "usage_key": "V"
    },
    "Event Booster": {
        "id": "event_booster",
        "effect": "Increases event item drop rates",
        "multiplier": 2.0,
        "detection_colors": [(0, 255, 0), (0, 240, 0)],
        "usage_key": "W"
    },
    "Event Charm": {
        "id": "event_charm",
        "effect": "Increases chance of rare event items",
        "multiplier": 3.0,
        "detection_colors": [(0, 0, 255), (0, 0, 240)],
        "usage_key": "X"
    }
}

# PS99 Collections API integration
API_INTEGRATION = {
    "collections_api_base": "https://ps99.biggamesapi.io/api",
    "endpoints": {
        "all_collections": "/collections",
        "pets": "/collection/Pets",
        "areas": "/collection/Areas",
        "zones": "/collection/Zones",
        "boosts": "/collection/Boosts",
        "enchants": "/collection/Enchants",
        "potions": "/collection/Potions",
        "items": "/collection/Items"
    },
    "documentation": "https://joekiller.github.io/node-ps99-api/#/collections"
}

# Complete database of all items from all sources
def create_comprehensive_database():
    """Combine all data into a single comprehensive database object"""
    return {
        "api_endpoints": API_ENDPOINTS,
        "pet_variants": PET_VARIANTS,
        "boosts": BOOSTS,
        "egg_types": EGG_TYPES,
        "worlds": WORLDS,
        "mining_resources": MINING_RESOURCES,
        "enchantments": ENCHANTMENTS,
        "events": EVENTS,
        "ui_elements": UI_ELEMENTS,
        "luck_enhancement_timings": LUCK_ENHANCEMENT_TIMINGS,
        "detection_avoidance": DETECTION_AVOIDANCE,
        "api_authentication": API_AUTHENTICATION,
        "potions": POTIONS,
        "glitch_drives": GLITCH_DRIVES,
        "enchant_items": ENCHANT_ITEMS,
        "luck_books": LUCK_BOOKS,
        "huge_hunter_items": HUGE_HUNTER_ITEMS,
        "special_event_items": SPECIAL_EVENT_ITEMS,
        "api_integration": API_INTEGRATION,
        "item_types": {
            "egg": "egg",
            "present": "present",
            "gift_bag": "gift_bag",
            "potion": "potion",
            "glitch_drive": "glitch_drive",
            "enchant": "enchant",
            "luck_book": "luck_book",
            "huge_hunter": "huge_hunter",
            "event_item": "event_item"
        }
    }

# Get the comprehensive database
PS99_DATABASE = create_comprehensive_database()