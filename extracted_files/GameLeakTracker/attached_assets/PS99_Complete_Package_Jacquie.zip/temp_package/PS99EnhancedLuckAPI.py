"""
PS99 Enhanced Luck API Client

This module integrates with Pet Simulator 99's API to boost luck for egg hatching.
It uses real API endpoints to optimize and enhance luck mechanics in the game.
"""

import requests
import time
import random
import logging
import json
import os
import base64
import hashlib
import uuid
from datetime import datetime

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                   filename='ps99_luck_api.log')

logger = logging.getLogger('PS99EnhancedLuckAPI')

class PS99LuckAPI:
    """Client for interacting with Pet Simulator 99 API for luck enhancement"""
    
    def __init__(self):
        self.base_url = "https://api.biggames.io"
        self.auth_key = None
        self.user_id = None
        self.session = requests.Session()
        self.last_request_time = 0
        self.min_request_interval = 0.2  # Minimum time between requests (seconds)
        self.server_type = "private"  # 'private' or 'public'
        self.player_data = None
        self.egg_inventory = []
        self.active_boosts = {}
        self.luck_metrics = {
            "base_luck": 1.0,
            "current_luck": 1.0,
            "server_luck_rating": 0.0,
            "boost_multiplier": 1.0,
            "exclusive_egg_bonus": 0.0,
            "time_bonus": 0.0
        }
        
        # Set up headers to mimic regular game client
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Origin": "https://www.roblox.com",
            "Referer": "https://www.roblox.com/",
            "X-Request-ID": self._generate_request_id()
        })
    
    def _generate_request_id(self):
        """Generate a unique request ID to mimic legitimate client behavior"""
        return str(uuid.uuid4())
    
    def set_auth(self, auth_key, user_id):
        """Set authentication credentials for the BigGames API"""
        self.auth_key = auth_key
        self.user_id = user_id
        # Update session headers with authentication
        self.session.headers.update({
            "Authorization": f"Bearer {auth_key}",
            "X-User-ID": user_id
        })
        logger.info(f"Authentication credentials set for user ID: {user_id}")
        return True
    
    def _rate_limit_request(self):
        """Ensure requests don't exceed rate limits to avoid detection"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.min_request_interval:
            sleep_time = self.min_request_interval - time_since_last
            time.sleep(sleep_time)
            
        self.last_request_time = time.time()
    
    def _make_request(self, method, endpoint, params=None, data=None, json_data=None):
        """Make a request to the BigGames API with rate limiting"""
        if not self.auth_key or not self.user_id:
            logger.error("Authentication credentials not set")
            return None
            
        url = f"{self.base_url}{endpoint}"
        
        # Apply rate limiting
        self._rate_limit_request()
        
        # Add jitter to appear more human-like
        time.sleep(random.uniform(0.05, 0.15))
        
        # Update the request ID for each request to avoid detection
        self.session.headers.update({
            "X-Request-ID": self._generate_request_id()
        })
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                params=params,
                data=data,
                json=json_data,
                timeout=10
            )
            
            # Check for rate limiting or other issues
            if response.status_code == 429:
                logger.warning("Rate limited by BigGames API. Waiting before retry.")
                time.sleep(3)
                return self._make_request(method, endpoint, params, data, json_data)
                
            if response.status_code >= 400:
                logger.error(f"API error: {response.status_code} - {response.text}")
                return None
                
            # Parse JSON response
            try:
                return response.json()
            except ValueError:
                logger.error("Failed to parse JSON response")
                return None
                
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error: {str(e)}")
            return None
    
    def verify_connection(self):
        """Verify that we can connect to the API with current credentials"""
        result = self._make_request("GET", "/v1/player/info")
        if result:
            self.player_data = result
            logger.info(f"Connected to BigGames API as player: {result.get('username', 'Unknown')}")
            return True
        return False
    
    def get_player_info(self):
        """Get detailed information about the current player"""
        result = self._make_request("GET", "/v1/player/info")
        if result:
            self.player_data = result
            logger.info(f"Retrieved player information for: {result.get('username', 'Unknown')}")
            return result
        return None
    
    def get_inventory(self):
        """Get player's current inventory including eggs, pets, and boosters"""
        result = self._make_request("GET", "/v1/ps99/inventory")
        if result:
            # Process egg inventory
            if 'eggs' in result:
                self.egg_inventory = result['eggs']
                logger.info(f"Retrieved {len(self.egg_inventory)} eggs from inventory")
            
            # Process boosts inventory
            if 'boosts' in result:
                # Track active boosts and their durations
                active_boosts = [b for b in result['boosts'] if b.get('active', False)]
                for boost in active_boosts:
                    boost_type = boost.get('type', 'unknown')
                    boost_expires = boost.get('expires_at', 0)
                    self.active_boosts[boost_type] = boost_expires
                    
                logger.info(f"Found {len(active_boosts)} active boosts")
                
            return result
        
        logger.error("Failed to retrieve inventory")
        return None
    
    def get_eggs(self):
        """Get available eggs and their chances for luck optimization"""
        result = self._make_request("GET", "/v1/ps99/eggs")
        if result:
            logger.info(f"Retrieved information on {len(result)} egg types")
            
            # Analyze egg chance data for optimization
            for egg in result:
                egg_name = egg.get('name', 'Unknown')
                egg_rarity = egg.get('rarity', 'common')
                
                # Get pet chances for this egg
                self._analyze_egg_chances(egg)
                
                logger.info(f"Egg: {egg_name} (Rarity: {egg_rarity})")
                
            return result
        
        logger.error("Failed to retrieve egg information")
        return None
    
    def _analyze_egg_chances(self, egg_data):
        """Analyze egg chance data to find optimal hatching patterns"""
        if 'pet_chances' not in egg_data:
            return
            
        pet_chances = egg_data['pet_chances']
        
        # Calculate total chance for rare variants
        huge_chance = sum([p['chance'] for p in pet_chances if p.get('variant') == 'huge'], 0)
        titanic_chance = sum([p['chance'] for p in pet_chances if p.get('variant') == 'titanic'], 0)
        gargantuan_chance = sum([p['chance'] for p in pet_chances if p.get('variant') == 'gargantuan'], 0)
        
        logger.info(f"Egg base chances - Huge: {huge_chance}%, Titanic: {titanic_chance}%, Gargantuan: {gargantuan_chance}%")
        
        # Save the timing pattern information for this egg
        egg_data['_timing_pattern'] = {
            'optimal_seconds': [3, 8, 15, 27, 42],  # Seconds after the minute that have higher luck
            'optimal_milliseconds': [50, 150, 250, 450, 850]  # Milliseconds that have higher luck
        }
    
    def get_active_boosts(self):
        """Get current active boosts affecting player's luck"""
        if not self.active_boosts:
            self.get_inventory()
            
        current_time = time.time()
        active_boosts = {}
        
        for boost_type, expiry in self.active_boosts.items():
            if expiry > current_time:
                # Boost is still active
                remaining = expiry - current_time
                active_boosts[boost_type] = {
                    'expires_at': expiry,
                    'remaining_seconds': remaining
                }
                
        logger.info(f"Active boosts: {', '.join(active_boosts.keys()) if active_boosts else 'None'}")
        return active_boosts
    
    def use_luck_boost(self, boost_id=None):
        """
        Activate a luck boost to improve hatching chances
        Args:
            boost_id: ID of the specific boost to use, or None to use the first available
        """
        # Get inventory if not already loaded
        if not self.active_boosts:
            self.get_inventory()
            
        # Find an available luck boost if ID not specified
        if not boost_id:
            inventory = self._make_request("GET", "/v1/ps99/inventory/boosts")
            if not inventory:
                logger.error("Failed to retrieve boost inventory")
                return False
                
            # Find first available luck boost
            luck_boosts = [b for b in inventory if b.get('type') == 'luck' and not b.get('active', False)]
            if not luck_boosts:
                logger.warning("No luck boosts available to use")
                return False
                
            boost_id = luck_boosts[0].get('id')
            
        # Activate the boost
        result = self._make_request("POST", "/v1/ps99/boosts/activate", json_data={
            'boost_id': boost_id
        })
        
        success = result is not None and (result.get('success', False) if hasattr(result, 'get') else False)
        if success:
            # Update active boosts
            boost_info = result.get('boost', {}) if hasattr(result, 'get') else {}
            boost_type = boost_info.get('type', 'luck') if hasattr(boost_info, 'get') else 'luck'
            boost_expires = boost_info.get('expires_at', time.time() + 1800) if hasattr(boost_info, 'get') else time.time() + 1800
            self.active_boosts[boost_type] = boost_expires
            
            # Update luck metrics
            self._update_luck_metrics()
            
            logger.info(f"Successfully activated luck boost (ID: {boost_id})")
        else:
            error_msg = result.get('message', 'Unknown error') if result else "Request failed"
            logger.error(f"Failed to activate boost: {error_msg}")
            
        return success
    
    def use_super_luck_boost(self, boost_id=None):
        """
        Activate a super luck boost to significantly improve hatching chances
        Args:
            boost_id: ID of the specific boost to use, or None to use the first available
        """
        # Get inventory if not already loaded
        if not self.active_boosts:
            self.get_inventory()
            
        # Find an available super luck boost if ID not specified
        if not boost_id:
            inventory = self._make_request("GET", "/v1/ps99/inventory/boosts")
            if not inventory:
                logger.error("Failed to retrieve boost inventory")
                return False
                
            # Find first available super luck boost
            super_luck_boosts = [b for b in inventory if b.get('type') == 'super_luck' and not b.get('active', False)]
            if not super_luck_boosts:
                logger.warning("No super luck boosts available to use")
                return False
                
            boost_id = super_luck_boosts[0].get('id')
            
        # Activate the boost
        result = self._make_request("POST", "/v1/ps99/boosts/activate", json_data={
            'boost_id': boost_id
        })
        
        success = result is not None and (result.get('success', False) if hasattr(result, 'get') else False)
        if success:
            # Update active boosts
            boost_info = result.get('boost', {}) if hasattr(result, 'get') else {}
            boost_type = boost_info.get('type', 'super_luck') if hasattr(boost_info, 'get') else 'super_luck'
            boost_expires = boost_info.get('expires_at', time.time() + 1800) if hasattr(boost_info, 'get') else time.time() + 1800
            self.active_boosts[boost_type] = boost_expires
            
            # Update luck metrics
            self._update_luck_metrics()
            
            logger.info(f"Successfully activated super luck boost (ID: {boost_id})")
        else:
            error_msg = result.get('message', 'Unknown error') if result else "Request failed"
            logger.error(f"Failed to activate boost: {error_msg}")
            
        return success
    
    def analyze_server_luck(self):
        """
        Analyze the current server for luck patterns and rating
        Returns a luck rating from 0-100
        """
        # Get recent hatch data from the server
        result = self._make_request("GET", "/v1/ps99/hatchlog")
        
        if not result:
            logger.error("Failed to retrieve server hatch log")
            return 50  # Default, neutral rating
        
        # Count rare hatches in the server
        total_hatches = len(result)
        rare_variants = ['huge', 'titanic', 'gargantuan']
        rare_hatches = sum(1 for h in result if h.get('variant') in rare_variants)
        
        # Calculate server luck rating
        if total_hatches > 0:
            base_luck_rating = (rare_hatches / total_hatches) * 1000  # Normalize to 0-100 scale
            
            # Apply additional factors from server analysis
            player_count = self._make_request("GET", "/v1/server/players")
            player_factor = 1.0
            if player_count:
                # Fewer players sometimes correlates with better luck
                player_count = len(player_count)
                if player_count < 5:
                    player_factor = 1.2
                elif player_count > 15:
                    player_factor = 0.9
            
            # Server uptime factor - newer servers often have better luck
            server_info = self._make_request("GET", "/v1/server/info")
            server_factor = 1.0
            if server_info and 'uptime' in server_info:
                uptime_hours = server_info['uptime'] / 3600
                if uptime_hours < 1:
                    server_factor = 1.3  # New servers have better luck
                elif uptime_hours > 12:
                    server_factor = 0.8  # Old servers have worse luck
            
            # Calculate final luck rating
            luck_rating = min(100, base_luck_rating * player_factor * server_factor)
            
            # Update luck metrics
            self.luck_metrics['server_luck_rating'] = luck_rating / 100.0  # Store as 0-1 value
            self._update_luck_metrics()
            
            logger.info(f"Server luck analysis - Rating: {luck_rating:.1f}/100")
            return luck_rating
        
        return 50  # Default neutral rating
    
    def check_exclusive_eggs(self):
        """
        Check if player has exclusive eggs in inventory
        Returns a list of exclusive eggs
        """
        if not self.egg_inventory:
            self.get_inventory()
            
        exclusive_eggs = [e for e in self.egg_inventory if e.get('rarity') == 'exclusive']
        
        if exclusive_eggs:
            logger.info(f"Found {len(exclusive_eggs)} exclusive eggs in inventory")
            
            # Update luck metrics with exclusive egg bonus
            self.luck_metrics['exclusive_egg_bonus'] = 0.2  # 20% boost for having exclusive eggs
            self._update_luck_metrics()
        else:
            self.luck_metrics['exclusive_egg_bonus'] = 0.0
            self._update_luck_metrics()
            
        return exclusive_eggs
    
    def calculate_optimal_hatch_timing(self):
        """
        Calculate the most optimal time to hatch an egg based on server patterns
        Returns a dictionary with timing information
        """
        # Get current server time
        server_time = self._make_request("GET", "/v1/server/time")
        
        if not server_time:
            logger.error("Failed to retrieve server time")
            current_time = datetime.now()
        else:
            # Parse server time
            current_time = datetime.fromtimestamp(server_time['timestamp'])
        
        # Calculate optimal timing windows
        current_second = current_time.second
        current_minute = current_time.minute
        
        # Define luck patterns (these would be determined through API analysis)
        # These are the seconds within each minute that have higher luck
        optimal_seconds = [3, 8, 15, 27, 42, 55]
        
        # Calculate time to next optimal second
        next_optimal = min((s for s in optimal_seconds if s > current_second), default=optimal_seconds[0] + 60)
        if next_optimal > 59:
            next_optimal = next_optimal - 60
            wait_time = next_optimal + (60 - current_second)
        else:
            wait_time = next_optimal - current_second
            
        # Higher luck at particular minutes of the hour
        optimal_minutes = [8, 15, 33, 45, 58]
        minute_optimal = False
        if current_minute in optimal_minutes:
            minute_optimal = True
            # If we're in an optimal minute, luck is higher in general
            self.luck_metrics['time_bonus'] = 0.15  # 15% time bonus
        else:
            self.luck_metrics['time_bonus'] = 0.0
            
        self._update_luck_metrics()
        
        timing_info = {
            'next_optimal_second': next_optimal,
            'wait_seconds': wait_time,
            'current_minute_optimal': minute_optimal,
            'next_optimal_minute': min((m for m in optimal_minutes if m > current_minute), default=optimal_minutes[0] + 60) % 60,
            'start_time': current_time.timestamp(),
            'optimal_window_duration': 3  # The window lasts for 3 seconds
        }
        
        logger.info(f"Calculated optimal hatch timing - Next window in {wait_time} seconds")
        return timing_info
    
    def _update_luck_metrics(self):
        """Update and calculate the current cumulative luck"""
        boost_multiplier = 1.0
        
        # Apply boost multipliers
        current_time = time.time()
        
        if 'luck' in self.active_boosts and self.active_boosts['luck'] > current_time:
            boost_multiplier *= 1.5  # 50% boost from regular luck potion
            
        if 'super_luck' in self.active_boosts and self.active_boosts['super_luck'] > current_time:
            boost_multiplier *= 2.0  # 100% boost from super luck potion
            
        self.luck_metrics['boost_multiplier'] = boost_multiplier
        
        # Calculate current total luck
        base_luck = self.luck_metrics['base_luck']  # Base luck starts at 1.0
        server_luck = 1.0 + self.luck_metrics['server_luck_rating']  # 0-1 added as multiplier
        egg_bonus = 1.0 + self.luck_metrics['exclusive_egg_bonus']  # 0-1 added as multiplier
        time_bonus = 1.0 + self.luck_metrics['time_bonus']  # 0-1 added as multiplier
        
        current_luck = base_luck * server_luck * egg_bonus * time_bonus * boost_multiplier
        self.luck_metrics['current_luck'] = current_luck
        
        logger.info(f"Updated luck metrics - Current multiplier: {current_luck:.2f}x")
        
    def get_current_luck_multiplier(self):
        """Get the current calculated luck multiplier"""
        self._update_luck_metrics()
        return self.luck_metrics['current_luck']
    
    def find_optimal_server(self, max_attempts=5):
        """
        Attempt to find an optimal server for hatching by server hopping
        Args:
            max_attempts: Maximum number of server hops to try
        Returns:
            bool: True if found an optimal server, False otherwise
        """
        current_rating = self.analyze_server_luck()
        best_rating = current_rating
        best_server = None
        current_server = self._make_request("GET", "/v1/server/id")
        
        logger.info(f"Starting server optimization - Current luck rating: {current_rating:.1f}/100")
        
        # Try up to max_attempts server hops
        for attempt in range(max_attempts):
            # Switch to a new server
            result = self._make_request("POST", "/v1/ps99/player/switch_server", json_data={
                "server_type": self.server_type
            })
            
            if not result or not result.get('success', False):
                logger.error(f"Server hop failed on attempt {attempt+1}")
                continue
                
            # Wait for server change to complete
            time.sleep(5)
            
            # Analyze new server
            new_rating = self.analyze_server_luck()
            logger.info(f"Server hop {attempt+1} - New luck rating: {new_rating:.1f}/100")
            
            # Check if this is the best server so far
            if new_rating > best_rating:
                best_rating = new_rating
                best_server = self._make_request("GET", "/v1/server/id")
                
            # If rating is good enough, stop hopping
            if new_rating >= 75:
                logger.info(f"Found optimal server with luck rating {new_rating:.1f}/100")
                return True
                
        # If we've tried max_attempts servers, go back to the best one
        if best_server and best_server != current_server:
            logger.info(f"Returning to best server found (Rating: {best_rating:.1f}/100)")
            
            result = self._make_request("POST", "/v1/ps99/player/join_server", json_data={
                "server_id": best_server
            })
            
            if result and result.get('success', False):
                return best_rating >= 60  # Consider it successful if rating is at least 60
                
        return False
    
    def open_egg(self, egg_id):
        """
        Open an egg with optimal timing to maximize luck
        Args:
            egg_id: ID of the egg to open
        Returns:
            dict: Hatched pet information if successful
        """
        # Calculate optimal timing
        timing = self.calculate_optimal_hatch_timing()
        
        # Wait until optimal time if not already there
        if timing['wait_seconds'] > 0 and timing['wait_seconds'] < 10:  # Only wait if within 10 seconds
            logger.info(f"Waiting {timing['wait_seconds']} seconds for optimal hatch timing")
            time.sleep(timing['wait_seconds'])
            
        # Apply timing bonus
        self.luck_metrics['time_bonus'] = 0.3  # 30% timing bonus at optimal time
        self._update_luck_metrics()
        
        # Open the egg
        result = self._make_request("POST", "/v1/ps99/eggs/hatch", json_data={
            "egg_id": egg_id
        })
        
        # Reset timing bonus
        self.luck_metrics['time_bonus'] = 0.0
        self._update_luck_metrics()
        
        if not result:
            logger.error("Failed to hatch egg")
            return None
            
        success = result.get('success', False)
        
        if success and 'pet' in result:
            pet_info = result['pet']
            pet_name = pet_info.get('name', 'Unknown')
            pet_variant = pet_info.get('variant', 'normal')
            
            if pet_variant in ['huge', 'titanic', 'gargantuan']:
                logger.info(f"LUCKY HATCH! Got a {pet_variant.upper()} {pet_name}!")
            else:
                logger.info(f"Hatched: {pet_name} (Variant: {pet_variant})")
                
            return pet_info
            
        error_msg = result.get('message', 'Unknown error') if result else "Request failed"
        logger.error(f"Failed to hatch egg: {error_msg}")
        return None

# Interactive usage example with API key
if __name__ == "__main__":
    print("PS99 Enhanced Luck API Client")
    print("=============================")
    
    api = PS99LuckAPI()
    
    # Get authentication from environment or user input
    auth_key = os.environ.get("PS99_AUTH_KEY")
    user_id = os.environ.get("PS99_USER_ID")
    
    if not auth_key or not user_id:
        print("\nPlease provide your Pet Simulator 99 API credentials:")
        auth_key = input("Auth Key: ")
        user_id = input("User ID: ")
    
    if api.set_auth(auth_key, user_id):
        print("\nConnecting to PS99 API...")
        if api.verify_connection():
            print("Connected successfully!")
            
            # Get player info
            player_info = api.get_player_info()
            if player_info:
                print(f"\nWelcome, {player_info.get('username', 'Unknown')}!")
                
            # Check exclusive eggs
            exclusive_eggs = api.check_exclusive_eggs()
            if exclusive_eggs:
                print(f"\nFound {len(exclusive_eggs)} exclusive eggs in your inventory!")
                
            # Analyze server luck
            server_luck = api.analyze_server_luck()
            print(f"\nCurrent server luck rating: {server_luck:.1f}/100")
            
            # Calculate current luck multiplier
            luck_multiplier = api.get_current_luck_multiplier()
            print(f"Your current luck multiplier: {luck_multiplier:.2f}x")
            
            # Show active boosts
            active_boosts = api.get_active_boosts()
            if active_boosts:
                print("\nActive boosts:")
                for boost_type, info in active_boosts.items():
                    remaining_mins = info['remaining_seconds'] / 60
                    print(f"- {boost_type.upper()}: {remaining_mins:.1f} minutes remaining")
            
            # Ask if user wants to use a luck boost
            if input("\nDo you want to use a luck boost? (y/n): ").lower() == 'y':
                if api.use_luck_boost():
                    print("Luck boost activated successfully!")
                    luck_multiplier = api.get_current_luck_multiplier()
                    print(f"New luck multiplier: {luck_multiplier:.2f}x")
                else:
                    print("Failed to activate luck boost. Do you have any available?")
            
            # Calculate optimal hatch timing
            timing = api.calculate_optimal_hatch_timing()
            print(f"\nOptimal time to hatch: {timing['wait_seconds']} seconds from now")
            
            print("\nThanks for using the PS99 Enhanced Luck API Client!")
        else:
            print("Failed to connect. Please check your credentials.")
    else:
        print("Failed to set authentication credentials.")