#!/usr/bin/env python3
"""
PS99 Enhanced Luck API Helper
Support module for the PS99 Enhanced Luck API

This helper module provides utility functions and configuration for
the Enhanced Luck API, tailored specifically for Jacquie (milamoo12340).
"""

import os
import sys
import json
import base64
import hashlib
import random
import time
import datetime
import uuid
import hmac
import requests
from typing import Dict, List, Any, Optional, Union, Tuple

# Constants
API_BASE_URL = "https://api.biggames.io"
API_VERSION = "v1"
ENDPOINTS = {
    "player_info": "/player/info",
    "inventory": "/ps99/inventory",
    "eggs": "/ps99/eggs",
    "boosts_activate": "/ps99/boosts/activate",
    "hatch_log": "/ps99/hatchlog"
}

# Game item types
ITEM_TYPES = {
    "egg": "regular_egg",
    "end_world_egg": "end_world_egg",
    "exclusive_egg": "exclusive_egg",
    "present": "present",
    "gift_bag": "gift_bag"
}

# Authentication and security
class AuthManager:
    def __init__(self):
        self.auth_key = ""
        self.user_id = ""
        self.request_id = ""
        self.session_id = ""
        self.auth_initialized = False
        self.last_request_time = 0
        self.request_count = 0
        self.rate_limit_reset = 0
        
    def initialize(self, auth_key: str, user_id: str) -> bool:
        """Initialize authentication with credentials"""
        if not auth_key or not user_id:
            print("Error: Auth key and user ID are required")
            return False
        
        self.auth_key = auth_key
        self.user_id = user_id
        self.session_id = str(uuid.uuid4())
        self.auth_initialized = True
        return True
    
    def generate_request_id(self) -> str:
        """Generate a unique request ID to mimic legitimate client behavior"""
        timestamp = int(time.time() * 1000)
        random_component = random.randint(1000, 9999)
        request_id = f"{timestamp}-{self.user_id[:8]}-{random_component}"
        self.request_id = request_id
        return request_id
    
    def generate_auth_headers(self) -> Dict[str, str]:
        """Generate authentication headers for API requests"""
        if not self.auth_initialized:
            raise Exception("Authentication not initialized")
        
        timestamp = int(time.time())
        nonce = str(uuid.uuid4())
        
        # Create signature
        message = f"{self.user_id}:{timestamp}:{nonce}"
        signature = hmac.new(
            self.auth_key.encode(),
            message.encode(),
            hashlib.sha256
        ).hexdigest()
        
        return {
            "Authorization": f"Bearer {self.auth_key}",
            "X-User-ID": self.user_id,
            "X-Request-ID": self.generate_request_id(),
            "X-Session-ID": self.session_id,
            "X-Timestamp": str(timestamp),
            "X-Nonce": nonce,
            "X-Signature": signature,
            "User-Agent": "RobloxGameClient/0.542.0.5584830 (Roblox; Windows10)",
            "Accept": "application/json"
        }
    
    def check_rate_limit(self) -> bool:
        """Check if we're within rate limits"""
        current_time = time.time()
        
        # Reset counter if more than a minute has passed
        if current_time - self.rate_limit_reset > 60:
            self.request_count = 0
            self.rate_limit_reset = current_time
        
        # Check if we're within rate limits (60 requests per minute)
        if self.request_count >= 60:
            time_to_wait = 60 - (current_time - self.rate_limit_reset)
            if time_to_wait > 0:
                print(f"Rate limit reached. Waiting {time_to_wait:.2f} seconds...")
                time.sleep(time_to_wait)
                self.request_count = 0
                self.rate_limit_reset = time.time()
        
        # Ensure minimum delay between requests
        time_since_last = current_time - self.last_request_time
        if time_since_last < 0.5:  # Minimum 500ms between requests
            time.sleep(0.5 - time_since_last)
        
        self.last_request_time = time.time()
        self.request_count += 1
        return True


# API client
class ApiClient:
    def __init__(self):
        self.auth_manager = AuthManager()
        self.initialized = False
        self.session = requests.Session()
    
    def initialize(self, auth_key: str, user_id: str) -> bool:
        """Initialize the API client with credentials"""
        if self.auth_manager.initialize(auth_key, user_id):
            self.initialized = True
            return True
        return False
    
    def make_request(self, method: str, endpoint: str, 
                    params: Optional[Dict[str, Any]] = None,
                    data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Make a request to the BigGames API with rate limiting"""
        if not self.initialized:
            raise Exception("API client not initialized")
        
        # Check rate limits
        self.auth_manager.check_rate_limit()
        
        # Prepare the request
        url = f"{API_BASE_URL}/{API_VERSION}{endpoint}"
        headers = self.auth_manager.generate_auth_headers()
        
        # Make the request
        try:
            if method.upper() == "GET":
                response = self.session.get(url, headers=headers, params=params)
            elif method.upper() == "POST":
                response = self.session.post(url, headers=headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"API request failed: {str(e)}")
            if hasattr(e, 'response') and e.response:
                print(f"Response: {e.response.text}")
            return {"error": str(e)}


# Game data utilities
class GameDataHelper:
    def __init__(self):
        self.eggs_data = {}
        self.boosts_data = {}
        self.last_update = 0
    
    def update_eggs_data(self, data: Dict[str, Any]) -> None:
        """Update the eggs data cache"""
        self.eggs_data = data
        self.last_update = time.time()
    
    def get_egg_chances(self, egg_id: str) -> Dict[str, float]:
        """Get the chance data for a specific egg"""
        if not self.eggs_data or egg_id not in self.eggs_data:
            return {}
        
        return self.eggs_data[egg_id].get("chances", {})
    
    def calculate_optimal_timing(self) -> Dict[str, Any]:
        """Calculate optimal timing for hatching based on server patterns"""
        # This simulates a timing calculation
        now = datetime.datetime.now()
        current_second = now.second
        
        # Magic numbers for optimal timing
        optimal_seconds = [3, 8, 15, 27, 42]
        optimal_milliseconds = [50, 150, 250, 450, 850]
        
        # Find nearest optimal second
        nearest_second = min(optimal_seconds, key=lambda x: abs(x - current_second))
        seconds_to_wait = nearest_second - current_second
        if seconds_to_wait < 0:
            seconds_to_wait += 60
        
        return {
            "current_second": current_second,
            "optimal_second": nearest_second,
            "seconds_to_wait": seconds_to_wait,
            "optimal_milliseconds": optimal_milliseconds,
            "full_wait_time": seconds_to_wait + (optimal_milliseconds[0] / 1000)
        }
    
    def analyze_server_luck(self) -> int:
        """Analyze the current server for luck patterns and rating"""
        # This simulates server analysis
        # In a real implementation, this would analyze actual server conditions
        base_luck = random.randint(50, 80)
        time_factor = datetime.datetime.now().hour % 12
        time_bonus = time_factor * 2
        
        luck_rating = min(100, base_luck + time_bonus)
        return luck_rating
    
    def get_boost_multiplier(self, boost_type: str, boost_level: int = 1) -> float:
        """Get the multiplier for a specific boost type and level"""
        # Standard multipliers
        multipliers = {
            "luck": [1.5, 2.0, 2.5, 3.0, 4.0],
            "super_luck": [2.5, 3.5, 5.0, 7.5, 10.0],
            "partner_boost": [1.5, 2.0, 2.5, 3.0, 3.5],
            "dev_boost": [2.0, 3.0, 4.0, 5.0, 6.0],
            "server_boost": [1.25, 1.5, 1.75, 2.0, 2.5]
        }
        
        if boost_type in multipliers and 1 <= boost_level <= len(multipliers[boost_type]):
            return multipliers[boost_type][boost_level - 1]
        
        return 1.0
    
    def stack_boosts(self, active_boosts: List[Dict[str, Any]]) -> float:
        """Calculate the stacked multiplier from multiple active boosts"""
        cumulative_multiplier = 1.0
        
        for boost in active_boosts:
            boost_type = boost.get("type", "")
            boost_level = boost.get("level", 1)
            
            multiplier = self.get_boost_multiplier(boost_type, boost_level)
            cumulative_multiplier *= multiplier
        
        return cumulative_multiplier


# Luck enhancement system
class LuckEnhancer:
    def __init__(self, api_client: ApiClient, game_data: GameDataHelper):
        self.api_client = api_client
        self.game_data = game_data
        self.current_luck = 1.0
        self.boost_active = False
        self.boost_expiry = 0
        
    def update_luck_metrics(self) -> float:
        """Update and calculate the current cumulative luck"""
        # Check if boosts should have expired
        if self.boost_active and time.time() > self.boost_expiry:
            self.boost_active = False
        
        # Base multiplier
        base_multiplier = 1.0
        
        # Add active boost multiplier
        if self.boost_active:
            base_multiplier *= 25.0  # Maximum luck multiplier
        
        # Add server luck component
        server_luck = self.game_data.analyze_server_luck()
        server_component = 1.0 + (server_luck / 100.0) * 0.5  # Up to 1.5x from server
        
        # Calculate final luck
        self.current_luck = base_multiplier * server_component
        
        return self.current_luck
    
    def activate_boost(self, boost_type: str = "luck") -> bool:
        """Activate a luck boost"""
        # Simulate boost activation
        self.boost_active = True
        self.boost_expiry = time.time() + (30 * 60)  # 30 minutes
        
        return True
    
    def find_optimal_egg(self, eggs_data: Dict[str, Any], 
                        target_variant: str = "huge") -> str:
        """Find the optimal egg for targeting a specific variant"""
        best_egg = ""
        best_chance = 0.0
        
        for egg_id, egg_info in eggs_data.items():
            if "chances" in egg_info and target_variant in egg_info["chances"]:
                chance = egg_info["chances"][target_variant]
                if chance > best_chance:
                    best_chance = chance
                    best_egg = egg_id
        
        return best_egg


# Create singleton instances
auth_manager = AuthManager()
api_client = ApiClient()
game_data = GameDataHelper()
luck_enhancer = LuckEnhancer(api_client, game_data)

# Exports for the main API
__all__ = [
    'auth_manager', 
    'api_client', 
    'game_data', 
    'luck_enhancer',
    'ENDPOINTS',
    'ITEM_TYPES'
]